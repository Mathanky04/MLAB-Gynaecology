package com.example.mathanky.gynocare4;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

import static com.example.mathanky.gynocare4.generalinfo.id;

public class obstetricinfo extends AppCompatActivity {

    EditText e1, e2, e3, lmp, edd, gestation, corrected;
    RadioGroup rg1;
    RadioButton selectedRadioButton;
    TextView t1,t2,t3,t4;
    SQLiteDatabase database;
    String table_query = "patient_id TEXT NOT NULL, " +
            "history_of_amenorrhea_months TEXT NOT NULL," +
            "history_of_amenorrhea_days TEXT NOT NULL," +
            "lmp TEXT NOT NULL," +
            " edd TEXT NOT NULL," +
            " gestational_age TEXT NOT NULL," +
            " corrected_edd TEXT NOT NULL," +
            " any_complaints1 TEXT DEFAULT \"Not Specified\"," +
            "update_status TEXT DEFAULT \"No\"," +
            "timestamp TEXT NOT NULL," +
            " primary key(patient_id), foreign key(patient_id) references general_information(patient_id)";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_obstetricinfo);
        e1 = (EditText) findViewById(R.id.amenorrhea_month_box);
        e2 = (EditText) findViewById(R.id.amenorrhea_day_box);
        e3 = (EditText) findViewById(R.id.obstetric_complaints);
        rg1 = (RadioGroup) findViewById(R.id.G_lmp);
        selectedRadioButton = (RadioButton) findViewById(R.id.G_lmp_yes);
        corrected = (EditText) findViewById(R.id.corrected_EDD);
        lmp = (EditText) findViewById(R.id.LMP);
        edd = (EditText) findViewById(R.id.EDD);
        gestation = (EditText) findViewById(R.id.gestation);
        t1=(TextView)findViewById(R.id.lmp_text);
        t2=(TextView)findViewById(R.id.edd_text);
        t3=(TextView)findViewById(R.id.gest_text);
        t4=(TextView)findViewById(R.id.weeks_text);
        lmp.setVisibility(View.GONE);
        edd.setVisibility(View.GONE);
        gestation.setVisibility(View.GONE);
        t1.setVisibility(View.GONE);
        t2.setVisibility(View.GONE);
        t3.setVisibility(View.GONE);
        //opening db
        database = openOrCreateDatabase("gynaecology", Context.MODE_PRIVATE, null);

        //creating table if doesn't exist
        database.execSQL("CREATE TABLE IF NOT EXISTS obstetric_information(" + table_query + ")");
    }

    @Override
    public void onBackPressed() { }

    public void onProceed(View view) {
        if (ValidationSuccess()) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
            String format = simpleDateFormat.format(new Date());
            String insert_query = "'" + id.toString().trim() + "'," +
                    "'" + e1.getText().toString().trim() + "'," +
                    "'" + e2.getText().toString().trim() + "'," +
                    "'" + lmp.getText().toString().trim() + "'," +
                    "'" + edd.getText().toString().trim() + "'," +
                    "'" + gestation.getText().toString().trim() + "'," +
                    "'" + corrected.getText().toString().trim() + "'," +
                    "'" +  e3.getText().toString().trim() + "'," +
                    "'" + "No" + "'," +
                    "'" + format.toString().trim() + "'";
            System.out.println("InsertQuery:" + insert_query);
            //inserting into database
            database.execSQL("INSERT INTO obstetric_information VALUES (" + insert_query + ")");
            Toast.makeText(getApplicationContext(), "Successful", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(getApplicationContext(), tri1_investigation.class);
            startActivity(intent);

        } else {
            Toast.makeText(getApplicationContext(), "Please check the details", Toast.LENGTH_LONG).show();
        }
    }

    private boolean ValidationSuccess() {

        boolean check = true;
        StringBuilder errMsg = new StringBuilder("");

        e1 = (EditText) findViewById(R.id.amenorrhea_month_box);
        e2 = (EditText) findViewById(R.id.amenorrhea_day_box);
        rg1 = (RadioGroup) findViewById(R.id.G_lmp);
        selectedRadioButton = (RadioButton) findViewById(R.id.G_lmp_yes);
        corrected = (EditText) findViewById(R.id.corrected_EDD);

        if (e1.getText().toString().equalsIgnoreCase("")) {
            e1.setError("Please enter a value");
            check = false;
        }

        if (e2.getText().toString().equalsIgnoreCase("")) {
            e2.setError("Please enter a value");
            check = false;
        }

        if (Integer.parseInt(e1.getText().toString()) > 10) {
            e1.setError("Exceeds limit!");
            return false;
        }

        if (Integer.parseInt(e2.getText().toString()) > 31) {
            e2.setError("Exceeds limit!");
            return false;
        }

        if (rg1.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (selectedRadioButton.isChecked()) {
            lmp = (EditText) findViewById(R.id.LMP);
            edd = (EditText) findViewById(R.id.EDD);

            if (lmp.getText().toString().equalsIgnoreCase("")) {
                lmp.setError("Please enter LMP");
                check = false;
            }

            if (edd.getText().toString().equalsIgnoreCase("")) {
                e2.setError("Please enter EDD");
                check = false;
            }
        }
        if (corrected.getText().toString().equalsIgnoreCase("")) {
            corrected.setError("Please enter the corrected EDD");
            check = false;
        }
        return check;
    }

    public void click(View view) {
        lmp.setVisibility(View.VISIBLE);
        edd.setVisibility(View.VISIBLE);
        gestation.setVisibility(View.VISIBLE);
        t1.setVisibility(View.VISIBLE);
        t2.setVisibility(View.VISIBLE);
        t3.setVisibility(View.VISIBLE);

    }

    public void click1(View view) {
        lmp = (EditText) findViewById(R.id.LMP);
        edd = (EditText) findViewById(R.id.EDD);
        gestation = (EditText) findViewById(R.id.gestation);

        lmp.setVisibility(View.GONE);
        edd.setVisibility(View.GONE);
        gestation.setVisibility(View.GONE);
        t1.setVisibility(View.GONE);
        t2.setVisibility(View.GONE);
        t3.setVisibility(View.GONE);
    }

}
