package com.example.mathanky.gynocare4;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class doctor_login extends AppCompatActivity {
    Button btn;
    EditText e1,e2;
    public static String doc_Name;
    public static String doe;
    Calendar calender;
    SimpleDateFormat simpledateformat;
    String Date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_login);
        e1=(EditText)findViewById(R.id.doctor_name_box);
        e2=(EditText)findViewById(R.id.doctor_date_box);
        btn=(Button)findViewById(R.id.button3);
        onbtn();

        TextView DisplayDateTime = (TextView) findViewById(R.id.doctor_date_box);

        calender = Calendar.getInstance();
        simpledateformat = new SimpleDateFormat("dd-MM-yyyy");
        Date = simpledateformat.format(calender.getTime());
        DisplayDateTime.setText(Date);
    }

    @Override
    public void onBackPressed() { }

    public void onbtn()
    {
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                doc_Name=e1.getText().toString();
                doe=e2.getText().toString();
                Intent intent=new Intent("com.example.mathanky.gynocare4.generalinfo");
                //intent.putExtra("doc_name",e1.getText().toString());
                //intent.putExtra("doe",e2.getText().toString());
                startActivity(intent);
            }
        });
    }
}
