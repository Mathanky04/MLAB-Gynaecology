package com.example.mathanky.gynocare4;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

import static com.example.mathanky.gynocare4.generalinfo.id;

public class pasthistory extends AppCompatActivity {
    EditText e1,e2,e3,e4,e5,e6, e7, e8, e9,e10;
    RadioGroup rg1, rg2, rg3, rg4, rg5,rg6,rg7,rg8, rg9;
    RadioButton selectedRadioButton, sr2, sr3, sr4, sr5, sr6, sr7, sr8, sr9;
    SQLiteDatabase database;
    String table_query = "patient_id TEXT ," +
            "gynaec_diabetes1 TEXT ,"+
            "gynaec_hypertension1 TEXT ," +
            "gynaec_tb1 TEXT ," +
            "gynaec_epilepsy TEXT ," +
            "gynaec_cardiac_disease TEXT ," +
            "gynaec_renal_disease TEXT ,"+
            "gynaec_veneral_disease TEXT ," +
            "gynaec_blood_transfusion TEXT , " +
            "gynaec_past_surgeries TEXT ," +
            "gynaec_others5 TEXT ," +
            "update_status TEXT DEFAULT \"No\"," +
            "timestamp TEXT ,primary key(patient_id)," +
            "foreign key(patient_id) references general_information(patient_id)";

    @Override
    public void onBackPressed() { }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pasthistory);
        e1 = (EditText)findViewById(R.id.g_diabetes_box) ;
        e2 = (EditText)findViewById(R.id.g_hypertension_box) ;
        e3 = (EditText)findViewById(R.id.g_TB_box) ;
        e4 = (EditText)findViewById(R.id.g_epilepsy_box) ;
        e5 = (EditText)findViewById(R.id.g_cardiac_box) ;
        e6 = (EditText)findViewById(R.id.g_renal_box) ;
        e7 = (EditText)findViewById(R.id.g_veneral_box) ;
        e8 = (EditText)findViewById(R.id.g_blood_box) ;
        e9 = (EditText)findViewById(R.id.g_past_surgery_box) ;
        e10=(EditText)findViewById(R.id.g_complaints_oi);
        rg2 = (RadioGroup)findViewById(R.id.g_hypertension);
        sr2 = (RadioButton)findViewById(R.id.g_hypertension_yes);
        rg3 = (RadioGroup)findViewById(R.id.g_TB);
        sr3 = (RadioButton)findViewById(R.id.g_TB_yes);
        rg4 = (RadioGroup)findViewById(R.id.g_epilepsy);
        sr4 = (RadioButton)findViewById(R.id.g_epi_yes);
        rg5 = (RadioGroup)findViewById(R.id.g_cardiac);
        sr5 = (RadioButton)findViewById(R.id.g_cardiac_yes);
        rg6 = (RadioGroup)findViewById(R.id.g_renal);
        sr6 = (RadioButton)findViewById(R.id.g_renal_yes);
        rg7 = (RadioGroup)findViewById(R.id.g_veneral);
        sr7 = (RadioButton)findViewById(R.id.g_veneral_yes);
        rg8 = (RadioGroup)findViewById(R.id.g_blood);
        sr8 = (RadioButton)findViewById(R.id.g_blood_yes);
        rg9 = (RadioGroup)findViewById(R.id.g_past_surgery);
        sr9 = (RadioButton)findViewById(R.id.g_past_surgery_yes);
        rg1=(RadioGroup)findViewById(R.id.g_diabetes);
        selectedRadioButton = (RadioButton)findViewById(R.id.g_diabetes_yes);
        e1.setVisibility(View.GONE);
        e2.setVisibility(View.GONE);
        e3.setVisibility(View.GONE);
        e4.setVisibility(View.GONE);
        e5.setVisibility(View.GONE);
        e6.setVisibility(View.GONE);
        e7.setVisibility(View.GONE);
        e8.setVisibility(View.GONE);
        e9.setVisibility(View.GONE);
        //opening db
        database = openOrCreateDatabase("gynaecology", Context.MODE_PRIVATE, null);

        //creating table if doesn't exist
        database.execSQL("CREATE TABLE IF NOT EXISTS gyno_pasthistory (" + table_query + ")");

    }
    public void onProceed(View view) {
        if (ValidationSuccess()) {
            String dia = "No", hyp = "No", tb1 = "No",epp1 =" Negative",crd="Negative",rnl="Negative",vnd="No",blt="No",psts="No";
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
            String format = simpleDateFormat.format(new Date());
            if(selectedRadioButton.isChecked())
                dia=e1.getText().toString();
            if(sr2.isChecked())
                hyp=e2.getText().toString();
            if(sr3.isChecked())
                tb1=e3.getText().toString();
            if(sr4.isChecked())
                epp1=e4.getText().toString();
            if(sr5.isChecked())
                crd=e5.getText().toString();
            if(sr6.isChecked())
                rnl=e6.getText().toString();
            if(sr7.isChecked())
                vnd=e7.getText().toString();
            if(sr8.isChecked())
                blt=e8.getText().toString();
            if(sr9.isChecked())
                psts=e9.getText().toString();
            String insert_query = "'" + id.toString().trim() + "'," +
                    "'" + dia + "'," +
                    "'" + hyp + "'," +
                    "'" + tb1 + "'," +
                    "'" + epp1+ "'," +
                    "'" + crd + "'," +
                    "'" + rnl + "'," +
                    "'" + vnd + "'," +
                    "'" + blt + "'," +
                    "'" + psts + "'," +
                    "'" + e10.getText().toString().trim() + "'," +
                    "'" + "No" + "'," +
                    "'" + format.toString().trim() + "'";
            System.out.println("InsertQuery:" + insert_query);
            //inserting into database
            database.execSQL("INSERT INTO gyno_pasthistory VALUES (" + insert_query + ")");
            Toast.makeText(getApplicationContext(), "Successful", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(getApplicationContext(),gynaec_family_history.class);
            startActivity(intent);

        } else {
            Toast.makeText(getApplicationContext(), "Please check the details", Toast.LENGTH_LONG).show();
        }


    }
    private boolean ValidationSuccess(){

        boolean check=true;
        StringBuilder errMsg = new StringBuilder("");
        if (rg1.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg2.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg3.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg4.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg5.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg6.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg7.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg8.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg9.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if(selectedRadioButton.isChecked())
        {
            e1 = (EditText)findViewById(R.id.g_diabetes_box) ;
            if (e1.getText().toString().equalsIgnoreCase("")){
                e1.setError("Please enter a value");
                check=false;
            }
        }

        if(sr2.isChecked())
        {
            e2 = (EditText)findViewById(R.id.g_hypertension_box) ;
            if (e2.getText().toString().equalsIgnoreCase("")){
                e2.setError("Please enter a value");
                check=false;
            }
        }

        if(sr3.isChecked())
        {
            e3 = (EditText)findViewById(R.id.g_TB_box) ;
            if (e3.getText().toString().equalsIgnoreCase("")){
                e3.setError("Please enter a value");
                check=false;
            }
        }

        if(sr4.isChecked())
        {
            e4 = (EditText)findViewById(R.id.g_epilepsy_box) ;
            if (e4.getText().toString().equalsIgnoreCase("")){
                e4.setError("Please enter a value");
                check=false;
            }
        }

        if(sr5.isChecked())
        {
            e5 = (EditText)findViewById(R.id.g_cardiac_box) ;
            if (e5.getText().toString().equalsIgnoreCase("")){
                e5.setError("Please enter a value");
                check=false;
            }
        }

        if(sr6.isChecked())
        {
            e6 = (EditText)findViewById(R.id.g_renal_box) ;
            if (e6.getText().toString().equalsIgnoreCase("")){
                e6.setError("Please enter a value");
                check=false;
            }
        }

        if(sr7.isChecked())
        {
            e5 = (EditText)findViewById(R.id.g_veneral_box) ;
            if (e5.getText().toString().equalsIgnoreCase("")){
                e5.setError("Please enter a value");
                check=false;
            }
        }

        if(sr8.isChecked())
        {
            e6 = (EditText)findViewById(R.id.g_blood_box) ;
            if (e6.getText().toString().equalsIgnoreCase("")){
                e6.setError("Please enter a value");
                check=false;
            }
        }
        if(sr9.isChecked())
        {
            e5 = (EditText)findViewById(R.id.g_past_surgery_box) ;
            if (e5.getText().toString().equalsIgnoreCase("")){
                e5.setError("Please enter a value");
                check=false;
            }
        }
        return check;
    }
    public void click(View view)
    {
        e1.setVisibility(View.VISIBLE);
    }
    public void click1(View view)
    {
        e1.setVisibility(View.GONE);
    }
    public void click2(View view)
    {
        e2.setVisibility(View.VISIBLE);
    }
    public void click3(View view)
    {
        e2.setVisibility(View.GONE);
    }
    public void click4(View view)
    {
        e3.setVisibility(View.VISIBLE);
    }
    public void click5(View view)
    {
        e3.setVisibility(View.GONE);
    }
    public void click6(View view)
    {
        e4.setVisibility(View.VISIBLE);
    }
    public void click7(View view)
    {
        e4.setVisibility(View.GONE);
    }
    public void click8(View view)
    {
        e5.setVisibility(View.VISIBLE);
    }
    public void click9(View view)
    {
        e5.setVisibility(View.GONE);
    }
    public void click10(View view)
    {
        e6.setVisibility(View.VISIBLE);
    }
    public void click11(View view)
    {
        e6.setVisibility(View.GONE);
    }
    public void click12(View view)
    {
        e7.setVisibility(View.VISIBLE);
    }
    public void click13(View view)
    {
        e7.setVisibility(View.GONE);
    }
    public void click14(View view)
    {
        e8.setVisibility(View.VISIBLE);
    }
    public void click15(View view)
    {
        e8.setVisibility(View.GONE);
    }
    public void click16(View view)
    {
        e9.setVisibility(View.VISIBLE);
    }
    public void click17(View view)
    {
        e9.setVisibility(View.GONE);
    }

}
