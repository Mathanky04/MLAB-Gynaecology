package com.example.mathanky.gynocare4;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

import static com.example.mathanky.gynocare4.generalinfo.id;

public class tri1_investigation extends AppCompatActivity {

    SQLiteDatabase database;
    EditText e4;
    EditText drug_box, other_box, hb,rbs;
    RadioGroup rg1, rg2, rg3, rg4, rg5, rg6, rg7, rg8;
    RadioButton selectedRadioButton,b1,b2,b3,b4,b5,b6,b7,b8,a1,a2,s1,s2,m1,m2,v1,v2,h1,h2,hbs1,hbs2;
    CheckBox hyperemesis, micturition, PIV, radiation, fever, folic, drug, other;
    String h = "Not Specified",bm = "Not Specified",bpsp = "Not Specified",re = "Not Specified",fwr = "Not Specified",
            fai = "Not Specified",odi = "Not Specified",o1 = "Not Specified",sc = "";
    String trimesterNo="Trimester-1",bgrt="",a="",s="",m="",vdrl="",hiv="",hbsag="";

    String table_query1 = "patient_id TEXT NOT NULL," +
            " hyperemesis TEXT DEFAULT \"Not Specified\", " +
            " burning_micturition TEXT DEFAULT \"Not Specified\"," +
            " bleeding_piv_spotting_piv TEXT DEFAULT \"Not Specified\"," +
            " radiation_exposure TEXT DEFAULT \"Not Specified\"," +
            " fever_with_rash TEXT DEFAULT \"Not Specified\"," +
            " folic_acid_intake TEXT DEFAULT \"Not Specified\"," +
            " other_drug_intake TEXT DEFAULT \"Not Specified\"," +
            " others1 TEXT DEFAULT \"Not Specified\"," +
            " scan DEFAULT \"Not Specified\","+
            " update_status TEXT DEFAULT \"No\"," +
            " timestamp TEXT NOT NULL," +
            " primary key(patient_id)," +
            " foreign key(patient_id) references general_information(patient_id)";

    String table_query2 = "patient_id TEXT NOT NULL," +
            "trimester_number TEXT NOT NULL," +
            " hb TEXT NOT NULL," +
            " blood_grouping_rh_typing TEXT NOT NULL," +
            " albumin TEXT NOT NULL," +
            " sugar TEXT NOT NULL," +
            " microscopy TEXT NOT NULL," +
            " vdrl TEXT NOT NULL," +
            " hiv_status TEXT NOT NULL," +
            " hbsag TEXT NOT NULL," +
            " rbs TEXT NOT NULL," +
            " others4 TEXT DEFAULT \"Not Specified\"," +
            " update_status TEXT DEFAULT \"No\"," +
            " timestamp TEXT NOT NULL," +
            " primary key(patient_id, trimester_number)," +
            " foreign key(patient_id) references general_information(patient_id)";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tri1_investigation);

        hyperemesis = (CheckBox) findViewById(R.id.hyperemesis);
        micturition = (CheckBox) findViewById(R.id.micturition);
        PIV = (CheckBox) findViewById(R.id.PIV);
        radiation = (CheckBox) findViewById(R.id.radiation);
        fever = (CheckBox) findViewById(R.id.fever);
        folic = (CheckBox) findViewById(R.id.folic);

        drug = (CheckBox) findViewById(R.id.drug);
        drug_box = (EditText)findViewById(R.id.drug_box);

        other = (CheckBox) findViewById(R.id.other);
        other_box = (EditText)findViewById(R.id.other_box);
        drug_box.setVisibility(View.GONE);
        other_box.setVisibility(View.GONE);
        hyperemesis.setVisibility(View.GONE);
        micturition.setVisibility(View.GONE);
        PIV.setVisibility(View.GONE);
        drug_box.setVisibility(View.GONE);
        other_box.setVisibility(View.GONE);
        radiation.setVisibility(View.GONE);
        fever.setVisibility(View.GONE);
        folic.setVisibility(View.GONE);
        drug.setVisibility(View.GONE);
        other.setVisibility(View.GONE);
        selectedRadioButton = (RadioButton)findViewById(R.id.first_trimester_complaints_yes);
        e4=(EditText)findViewById(R.id.first_trimester_others);
        //opening db
        database = openOrCreateDatabase("gynaecology", Context.MODE_PRIVATE, null);

        //creating table if doesn't exist
        database.execSQL("CREATE TABLE IF NOT EXISTS first_trimester(" + table_query1 + ")");
        database.execSQL("CREATE TABLE IF NOT EXISTS investigations(" + table_query2 + ")");

    }

    @Override
    public void onBackPressed() { }

    public void onProceed(View view){
        onclickAssign2();
        if(ValidationSuccess()){
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
            String format = simpleDateFormat.format(new Date());
            String insert_query1 = "'" + id.toString().trim() + "'," +
                    "'" + h + "'," +
                    "'" + bm + "'," +
                    "'" + bpsp + "'," +
                    "'" + re + "'," +
                    "'" + fwr + "'," +
                    "'" + fai + "'," +
                    "'" + odi + "'," +
                    "'" + o1 + "'," +
                    "'" + sc + "'," +
                    "'" + "No" + "'," +
                    "'" + format.trim() + "'";
            String insert_query2 = "'" + id.toString().trim() + "'," +
                    "'" + trimesterNo + "'," +
                    "'" + hb.getText().toString().trim() + "'," +
                    "'" + bgrt + "'," +
                    "'" + a + "'," +
                    "'" + s + "'," +
                    "'" + m + "'," +
                    "'" + vdrl + "'," +
                    "'" + hiv + "'," +
                    "'" + hbsag + "'," +
                    "'" + rbs.getText().toString().trim() + "'," +
                    "'" + e4.getText().toString().trim() + "'," +
                    "'" + "No" + "'," +
                    "'" + format.trim() + "'";
            System.out.println("InsertQuery:" + insert_query1);
            System.out.println("InsertQuery:" + insert_query2);
            //inserting into database
            database.execSQL("INSERT INTO first_trimester VALUES (" + insert_query1 + ")");
            database.execSQL("INSERT INTO investigations VALUES (" + insert_query2 + ")");
            Toast.makeText(getApplicationContext(), "Successful", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(getApplicationContext(), tri2_investigation.class);
            startActivity(intent);
        }else{
            Toast.makeText(getApplicationContext(), "Please check the details", Toast.LENGTH_LONG).show();
        }
    }

    private boolean ValidationSuccess(){
        boolean check=true;
        StringBuilder errMsg = new StringBuilder("");

        hb = (EditText)findViewById(R.id.hb) ;
        rg2 = (RadioGroup)findViewById(R.id.albumin);
        rg3 = (RadioGroup)findViewById(R.id.sugar);
        rg4 = (RadioGroup)findViewById(R.id.microscopy);
        rg5 = (RadioGroup)findViewById(R.id.vdrl);
        rg6 = (RadioGroup)findViewById(R.id.hiv);
        rg7 = (RadioGroup)findViewById(R.id.hbsag);
        rg8 = (RadioGroup)findViewById(R.id.first_blood_group);
        rbs = (EditText)findViewById(R.id.rbs);

        rg1=(RadioGroup)findViewById(R.id.first_trimester_complaints);
        selectedRadioButton = (RadioButton)findViewById(R.id.first_trimester_complaints_yes);


        if (hb.getText().toString().equalsIgnoreCase("")){
            hb.setError("Please enter a value");
            check=false;
        }

        if (Integer.parseInt(hb.getText().toString()) > 100) {
            hb.setError("Exceeds limit! Please enter a valid percentage");
            return false;
        }

        if (rbs.getText().toString().equalsIgnoreCase("")){
            hb.setError("Please enter a value");
            check=false;
        }



        if (rg1.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg2.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg3.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg4.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg5.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg6.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg7.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg8.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if(selectedRadioButton.isChecked())
        {
            hyperemesis = (CheckBox) findViewById(R.id.hyperemesis);
            micturition = (CheckBox) findViewById(R.id.micturition);
            PIV = (CheckBox) findViewById(R.id.PIV);
            radiation = (CheckBox) findViewById(R.id.radiation);
            fever = (CheckBox) findViewById(R.id.fever);
            folic = (CheckBox) findViewById(R.id.folic);

            drug = (CheckBox) findViewById(R.id.drug);
            drug_box = (EditText)findViewById(R.id.drug_box);

            other = (CheckBox) findViewById(R.id.other);
            other_box = (EditText)findViewById(R.id.other_box);

            if (!(hyperemesis.isChecked() || micturition.isChecked() || PIV.isChecked() || radiation.isChecked() || fever.isChecked() || folic.isChecked() || drug.isChecked() || other.isChecked())){
                hyperemesis.setError("Please select an option");
                check=false;
            }

            else if(drug.isChecked()&& drug_box.getText().toString().equalsIgnoreCase("")){
                drug.setError("Please enter  a value");
                check=false;
            }

            else if(other.isChecked()&& other_box.getText().toString().equalsIgnoreCase("")){
                drug.setError("Please enter a value");
                check=false;
            }

        }
        return check;
    }

    public void click(View view)
    {
        hyperemesis = (CheckBox) findViewById(R.id.hyperemesis);
        micturition = (CheckBox) findViewById(R.id.micturition);
        PIV = (CheckBox) findViewById(R.id.PIV);
        radiation = (CheckBox) findViewById(R.id.radiation);
        fever = (CheckBox) findViewById(R.id.fever);
        folic = (CheckBox) findViewById(R.id.folic);
        drug = (CheckBox) findViewById(R.id.drug);
        other = (CheckBox) findViewById(R.id.other);
        hyperemesis.setVisibility(View.VISIBLE);
        micturition.setVisibility(View.VISIBLE);
        PIV.setVisibility(View.VISIBLE);
        radiation.setVisibility(View.VISIBLE);
        fever.setVisibility(View.VISIBLE);
        folic.setVisibility(View.VISIBLE);
        drug.setVisibility(View.VISIBLE);
        other.setVisibility(View.VISIBLE);

    }

    public void click2(View view)
    {
        drug_box = (EditText)findViewById(R.id.drug_box);
        drug_box.setVisibility(View.VISIBLE);

    }

    public void click3(View view)
    {
        other_box = (EditText)findViewById(R.id.other_box);
        other_box.setVisibility(View.VISIBLE);

    }
    public void click1(View view)
    {
        hyperemesis = (CheckBox) findViewById(R.id.hyperemesis);
        micturition = (CheckBox) findViewById(R.id.micturition);
        PIV = (CheckBox) findViewById(R.id.PIV);
        radiation = (CheckBox) findViewById(R.id.radiation);
        fever = (CheckBox) findViewById(R.id.fever);
        folic = (CheckBox) findViewById(R.id.folic);

        drug = (CheckBox) findViewById(R.id.drug);
        drug_box = (EditText)findViewById(R.id.drug_box);

        other = (CheckBox) findViewById(R.id.other);
        other_box = (EditText)findViewById(R.id.other_box);

        drug_box.setVisibility(View.GONE);
        other_box.setVisibility(View.GONE);

        hyperemesis.setVisibility(View.GONE);
        micturition.setVisibility(View.GONE);
        PIV.setVisibility(View.GONE);
        radiation.setVisibility(View.GONE);
        fever.setVisibility(View.GONE);
        folic.setVisibility(View.GONE);
        drug.setVisibility(View.GONE);
        other.setVisibility(View.GONE);

    }

    public void onclickAssign(View view)
    {
        b1 = (RadioButton)findViewById(R.id.first_blood_group_A_plus);
        b2 = (RadioButton)findViewById(R.id.first_blood_group_A_minus);
        b3 = (RadioButton)findViewById(R.id.first_blood_group_B_plus);
        b4 = (RadioButton)findViewById(R.id.first_blood_group_B_minus);
        b5 = (RadioButton)findViewById(R.id.first_blood_group_O_plus);
        b6 = (RadioButton)findViewById(R.id.first_blood_group_O_minus);
        b7 = (RadioButton)findViewById(R.id.first_blood_group_AB_plus);
        b8 = (RadioButton)findViewById(R.id.first_blood_group_AB_minus);
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();
        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.first_blood_group_A_plus:
                if (checked)
                    bgrt="A+";
                break;
            case R.id.first_blood_group_A_minus:
                if (checked)
                    bgrt="A-";
                break;
            case R.id.first_blood_group_B_plus:
                if (checked)
                    bgrt="B+";
                break;
            case R.id.first_blood_group_B_minus:
                if (checked)
                    bgrt="B-";
                break;
            case R.id.first_blood_group_O_plus:
                if (checked)
                    bgrt="O+";
                break;
            case R.id.first_blood_group_O_minus:
                if (checked)
                    bgrt="O-";
                break;
            case R.id.first_blood_group_AB_plus:
                if (checked)
                    bgrt="AB+";
                break;
            case R.id.first_blood_group_AB_minus:
                if (checked)
                    bgrt="AB-";
                break;
        }
    }

    public void onclickAssign2()
    {
        hyperemesis = (CheckBox) findViewById(R.id.hyperemesis);
        micturition = (CheckBox) findViewById(R.id.micturition);
        PIV = (CheckBox) findViewById(R.id.PIV);
        radiation = (CheckBox) findViewById(R.id.radiation);
        fever = (CheckBox) findViewById(R.id.fever);
        folic = (CheckBox) findViewById(R.id.folic);
        drug = (CheckBox) findViewById(R.id.drug);
        drug_box = (EditText)findViewById(R.id.drug_box);
        other = (CheckBox) findViewById(R.id.other);
        if(selectedRadioButton.isChecked()) {
            if (hyperemesis.isChecked())
            {
                h = "Yes";
            }
            else
            {
                h="No";
            }
            if (micturition.isChecked()) {
                bm = "Yes";
            }
            else
            {
                bm="No";
            }
            if (PIV.isChecked()) {
                bpsp = "Yes";
            }
            else
            {
                bpsp="No";
            }
            if (radiation.isChecked()) {
                re = "Yes";
            }
            else
            {
                re="No";
            }
            if (fever.isChecked()) {
                fwr = "Yes";
            }
            else
            {
                fwr="No";
            }
            if (folic.isChecked()) {
                fai = "Yes";
            }
            else
            {
                fai="No";
            }
            if (drug.isChecked()) {
                odi = drug_box.getText().toString();
            }
            else
            {
                odi="No";
            }
            if (other.isChecked()) {
                o1 = other_box.getText().toString();
            }
            else {
                o1 = "No";
            }
        }
    }

    public void onclickAssign3(View view)
    {
        a1=(RadioButton)findViewById(R.id.albumin_normal);
        a2=(RadioButton)findViewById(R.id.albumin_abnormal);
        s1=(RadioButton)findViewById(R.id.sugar_normal);
        s2=(RadioButton)findViewById(R.id.sugar_abnormal);
        m1=(RadioButton)findViewById(R.id.microscopy_normal);
        m2=(RadioButton)findViewById(R.id.microscopy_abnormal);
        v1=(RadioButton)findViewById(R.id.vdrl_reactive);
        v2=(RadioButton)findViewById(R.id.vdrl_non_reactive);
        h1=(RadioButton)findViewById(R.id.hiv_reactive);
        h2=(RadioButton)findViewById(R.id.hiv_non_reactive);
        hbs1=(RadioButton)findViewById(R.id.hbsag_reactive);
        hbs2=(RadioButton)findViewById(R.id.hbsag_non_reactive);
        rbs=(EditText)findViewById(R.id.rbs);

        boolean checked = ((RadioButton) view).isChecked();
        switch(view.getId()) {
            case R.id.albumin_normal:
                if(checked)
                {
                    a="Normal";
                }
                break;
            case R.id.sugar_normal:
                if(checked)
                {
                    s="Normal";
                }
                break;
            case R.id.microscopy_normal:
                if(checked)
                {
                    m="Normal";
                }
                break;
            case R.id.vdrl_reactive:
                if(checked)
                {
                    vdrl="Reactive";
                }
                break;
            case R.id.hiv_reactive:
                if(checked)
                {
                    hiv="Reactive";
                }
                break;
            case R.id.hbsag_reactive:
                if(checked)
                {
                    hbsag="Reactive";
                }
                break;
            case R.id.albumin_abnormal:
                if(checked)
                {
                    a="Abnormal";
                }
                break;
            case R.id.sugar_abnormal:
                if(checked)
                {
                    s="Abnormal";
                }
                break;
            case R.id.microscopy_abnormal:
                if(checked)
                {
                    m="Abnormal";
                }
                break;
            case R.id.vdrl_non_reactive:
                if(checked)
                {
                    vdrl="Non Reactive";
                }
                break;
            case R.id.hiv_non_reactive:
                if(checked)
                {
                    hiv="Non Reactive";
                }
                break;
            case R.id.hbsag_non_reactive:
                if(checked)
                {
                    hbsag="Non Reactive";
                }
                break;
        }
    }

}
