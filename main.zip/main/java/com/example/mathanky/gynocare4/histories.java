package com.example.mathanky.gynocare4;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import static com.example.mathanky.gynocare4.generalinfo.id;

public class histories extends AppCompatActivity {

    SQLiteDatabase database;
    String table_history="patient_id TEXT ,menstrual_history TEXT , contraceptive_history TEXT , past_history TEXT , family_history TEXT ,update_status TEXT DEFAULT \"No\",timestamp TEXT ,primary key(patient_id), foreign key(patient_id) references general_information(patient_id)";
    String table_personal_history="patient_id TEXT ,diet TEXT , sleep TEXT , addictive_habits TEXT , allergies_known TEXT ,update_status TEXT DEFAULT \"No\",timestamp TEXT , primary key(patient_id), foreign key(patient_id) references general_information(patient_id)";
    EditText m_box, c_box,p_box, f_box,addictive_box, allergies_box;
    RadioButton m1,m2,c1,c2,p1,p2,f1,f2,d1,d2,s1,s2,ad1,ad2,al1,al2;
    RadioGroup rg1, rg2, rg3, rg4, rg5,rg6,rg7,rg8;
    Button btnNext;

    @Override
    public void onBackPressed() { }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_histories);
        database = openOrCreateDatabase("gynaecology", Context.MODE_PRIVATE, null);
        database.execSQL("CREATE TABLE IF NOT EXISTS history_table(" + table_history + ")");
        database.execSQL("CREATE TABLE IF NOT EXISTS personal_history(" + table_personal_history + ")");
        m1=(RadioButton)findViewById(R.id.menstrual_history_regular);
        m2=(RadioButton)findViewById(R.id.menstrual_history_irregular);
        c1=(RadioButton)findViewById(R.id.contraceptive_history_yes);
        c2=(RadioButton)findViewById(R.id.contraceptive_history_no);
        p1=(RadioButton)findViewById(R.id.past_history_significant);
        p2=(RadioButton)findViewById(R.id.past_history_insignificant);
        f1=(RadioButton)findViewById(R.id.family_history_significant);
        f2=(RadioButton)findViewById(R.id.family_history_insignificant);
        d1=(RadioButton)findViewById(R.id.diet_veg);
        d2=(RadioButton)findViewById(R.id.diet_mixed);
        s1=(RadioButton)findViewById(R.id.sleep_normal);
        s2=(RadioButton)findViewById(R.id.sleep_disturbed);
        ad1=(RadioButton)findViewById(R.id.addictive_habits_yes);
        ad2=(RadioButton)findViewById(R.id.addictive_habits_no);
        al1=(RadioButton)findViewById(R.id.allergies_known_yes);
        al2=(RadioButton)findViewById(R.id.allergies_known_no);
        m_box=(EditText)findViewById(R.id.menstrual_history_box);
        c_box = (EditText)findViewById(R.id.contraceptive_history_box) ;
        p_box = (EditText)findViewById(R.id.past_history_box) ;
        f_box = (EditText)findViewById(R.id.family_history_box) ;
        addictive_box = (EditText)findViewById(R.id.addictive_habits_box) ;
        allergies_box = (EditText)findViewById(R.id.allergies_known_box) ;
        rg1=(RadioGroup)findViewById(R.id.menstrual_history);
        rg2 = (RadioGroup)findViewById(R.id.contraceptive_history);
        rg3 = (RadioGroup)findViewById(R.id.past_history);
        rg4 = (RadioGroup)findViewById(R.id.family_history);
        rg5 = (RadioGroup)findViewById(R.id.addictive_habits);
        rg6 = (RadioGroup)findViewById(R.id.allergies_known);
        btnNext=(Button)findViewById(R.id.next_page6);
        m_box.setVisibility(View.GONE);
        c_box.setVisibility(View.GONE);
        p_box.setVisibility(View.GONE);
        f_box.setVisibility(View.GONE);
        addictive_box.setVisibility(View.GONE);
        allergies_box.setVisibility(View.GONE);
        onButton();
    }
    public void onButton()
    {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        final String format = simpleDateFormat.format(new Date());
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ValidationSuccess())
                {
                    String mens="Regular",cons="Insignificant",past="Insignificant",fam="Insignificant",addict="No",aller="No";
                    String d="",s="";
                    if(m2.isChecked())
                        mens=m_box.getText().toString();
                    if(c1.isChecked())
                        cons=c_box.getText().toString();
                    if(p1.isChecked())
                        past=p_box.getText().toString();
                    if(f1.isChecked())
                        fam=f_box.getText().toString();
                    if(d1.isChecked())
                        d="Veg";
                    else if(d2.isChecked())
                        d="Mixed";
                    if(s1.isChecked())
                        s="Normal";
                    else if(s2.isChecked())
                        s="Disturbed";
                    if(ad1.isChecked())
                        addict=addictive_box.getText().toString();
                    if(al1.isChecked())
                        aller=allergies_box.getText().toString();
                    String insert_history_table ="'"+id.toString().trim()+"','"+mens.trim()+"','"+cons.trim()+"','"+past.trim()+"','"+fam.trim()+ "','" + "No" + "','" +format.toString().trim()+"'";
                    String insert_personal_history="'"+id.toString().trim()+"','"+d.trim()+"','"+s.trim()+"','"+addict.trim()+"','"+aller.trim()+ "','" + "No" + "','" +format.toString().trim()+"'";

                    System.out.println("InsertQuery:" + insert_history_table);
                    System.out.println("InsertQuery:" + insert_personal_history);
                    //inserting into database
                    database.execSQL("INSERT INTO history_table VALUES (" + insert_history_table + ")");
                    database.execSQL("INSERT INTO personal_history VALUES (" +insert_personal_history+" )");
                    Toast.makeText(getApplicationContext(), "Successful", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), Generalphysicalexamination.class);
                    startActivity(intent);

                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Please check the details", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private boolean ValidationSuccess(){

        boolean check=true;
        StringBuilder errMsg = new StringBuilder("");

        if (rg1.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg2.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg3.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg4.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg5.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg6.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }




        if(m2.isChecked())
        {
            if (m_box.getText().toString().equalsIgnoreCase("")){
                m_box.setError("Please enter a value");
                check=false;
            }
        }

        if(c1.isChecked())
        {
            if (c_box.getText().toString().equalsIgnoreCase("")){
                c_box.setError("Please enter a value");
                check=false;
            }
        }

        if(p1.isChecked())
        {
            if (p_box.getText().toString().equalsIgnoreCase("")){
                p_box.setError("Please enter a value");
                check=false;
            }
        }

        if(f1.isChecked())
        {
            if (f_box.getText().toString().equalsIgnoreCase("")){
                f_box.setError("Please enter a value");
                check=false;
            }
        }

        if(ad1.isChecked())
        {
            if (addictive_box.getText().toString().equalsIgnoreCase("")){
                addictive_box.setError("Please enter a value");
                check=false;
            }
        }

        if(al1.isChecked())
        {
            if (allergies_box.getText().toString().equalsIgnoreCase("")){
                allergies_box.setError("Please enter a value");
                check=false;
            }
        }



        return check;
    }
    public void click(View view)
    {
        m_box.setVisibility(View.VISIBLE);
    }

    public void click1(View view)
    {
        m_box.setVisibility(View.GONE);
    }

    public void click2(View view)
    {
        c_box.setVisibility(View.VISIBLE);
    }

    public void click3(View view)
    {
        c_box.setVisibility(View.GONE);
    }

    public void click4(View view)
    {
        p_box.setVisibility(View.VISIBLE);
    }

    public void click5(View view)
    {
        p_box.setVisibility(View.GONE);
    }

    public void click6(View view)
    {
        f_box.setVisibility(View.VISIBLE);
    }

    public void click7(View view)
    {
        f_box.setVisibility(View.GONE);
    }

    public void click8(View view)
    {
        addictive_box.setVisibility(View.VISIBLE);
    }

    public void click9(View view)
    {
        addictive_box.setVisibility(View.GONE);
    }

    public void click10(View view)
    {
        allergies_box.setVisibility(View.VISIBLE);
    }

    public void click11(View view)
    {
        allergies_box.setVisibility(View.GONE);
    }
}
