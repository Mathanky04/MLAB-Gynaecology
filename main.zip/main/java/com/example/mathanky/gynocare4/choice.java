package com.example.mathanky.gynocare4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import static com.example.mathanky.gynocare4.generalinfo.id;
public class choice extends AppCompatActivity {

    private static Button btno, btng;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choice);
        btno=(Button)findViewById(R.id.button_o);
        btng=(Button)findViewById(R.id.button_g);
        onBtnO();
        onBtnG();
    }

    @Override
    public void onBackPressed() { }

    public void onBtnO()
    {
        btno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),obstetricinfo.class);
                startActivity(intent);
            }
        });
    }

    public void onBtnG()
    {
        btng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),gynaec_complaints_obstetric_history.class);
                startActivity(intent);
            }
        });
    }
}
