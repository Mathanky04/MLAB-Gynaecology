package com.example.mathanky.gynocare4;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import static com.example.mathanky.gynocare4.generalinfo.id;
public class tri3_investigation extends AppCompatActivity {

    SQLiteDatabase database;

    EditText e1, e2, e4;
    EditText third_other_box, third_hb, third_rbs;
    RadioGroup rg1, rg2, rg3, rg4, rg5, rg6, rg7, rg8;
    RadioButton selectedRadioButton, b1, b2, b3, b4, b5, b6, b7, b8, a1, a2, s1, s2, m1, m2, v1, v2, h1, h2, hbs1, hbs2;
    CheckBox abdomen, leak_piv, bleed_piv, foetal, third_pih, third_iron, third_calcium, third_other;
    String pain="Not Specified", leak="Not Specified", bleed="Not Specified", pi="Not Specified", calcium="Not Specified", iront="Not Specified", foet="Not Specified", to="Not Specified", trimesterNo = "Trimester-3", bgrt="",
            a = "Normal", s, m, vdrl, hiv, hbsag;

    String table_query1 = "patient_id TEXT NOT NULL," +
            "pain_in_abdomen TEXT DEFAULT \"Not Specified\"," +
            "leak_piv2 TEXT DEFAULT \"Not Specified\"," +
            "bleeding_piv TEXT DEFAULT \"Not Specified\"," +
            "foetal_movements TEXT DEFAULT \"Not Specified\"," +
            "pih_history2 TEXT DEFAULT \"Not Specified\"," +
            " iron_tablets2 TEXT DEFAULT \"Not Specified\"," +
            "calcium_tablets2 TEXT DEFAULT \"Not Specified\", " +
            "others3 TEXT DEFAULT \"Not Specified\"," +
            "growth_scan TEXT NOT NULL," +
            "update_status TEXT DEFAULT \"No\"," +
            "timestamp TEXT NOT NULL," +
            "primary key(patient_id), foreign key(patient_id) references general_information(patient_id)";
    String table_query2 = "patient_id TEXT NOT NULL," +
            "trimester_number TEXT NOT NULL," +
            " hb TEXT NOT NULL," +
            " blood_grouping_rh_typing TEXT NOT NULL," +
            " albumin TEXT NOT NULL," +
            " sugar TEXT NOT NULL," +
            " microscopy TEXT NOT NULL," +
            " vdrl TEXT NOT NULL," +
            " hiv_status TEXT NOT NULL," +
            " hbsag TEXT NOT NULL," +
            " rbs TEXT NOT NULL," +
            " others4 TEXT DEFAULT \"Not Specified\"," +
            " update_status TEXT DEFAULT \"No\"," +
            " timestamp TEXT NOT NULL," +
            " primary key(patient_id, trimester_number)," +
            " foreign key(patient_id) references general_information(patient_id)";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tri3_investigation);
        e2 = (EditText) findViewById(R.id.third_trimester_others);
        abdomen = (CheckBox) findViewById(R.id.abdomen);
        leak_piv = (CheckBox) findViewById(R.id.leak_piv);
        bleed_piv = (CheckBox) findViewById(R.id.third_bleeding_piv);
        third_pih = (CheckBox) findViewById(R.id.third_pih);
        foetal = (CheckBox) findViewById(R.id.foetal);
        third_iron = (CheckBox) findViewById(R.id.third_iron);
        third_calcium = (CheckBox) findViewById(R.id.third_calcium);

        third_other = (CheckBox) findViewById(R.id.third_other);
        third_other_box = (EditText) findViewById(R.id.third_other_box);

        third_other_box.setVisibility(View.GONE);
        abdomen.setVisibility(View.GONE);
        leak_piv.setVisibility(View.GONE);
        bleed_piv.setVisibility(View.GONE);
        third_pih.setVisibility(View.GONE);
        foetal.setVisibility(View.GONE);
        third_iron.setVisibility(View.GONE);
        third_other.setVisibility(View.GONE);
        third_calcium.setVisibility(View.GONE);
        third_hb = (EditText) findViewById(R.id.third_hb);
        rg2 = (RadioGroup) findViewById(R.id.third_albumin);
        rg3 = (RadioGroup) findViewById(R.id.third_sugar);
        rg4 = (RadioGroup) findViewById(R.id.third_microscopy);
        rg5 = (RadioGroup) findViewById(R.id.third_vdrl);
        rg6 = (RadioGroup) findViewById(R.id.third_hiv);
        rg7 = (RadioGroup) findViewById(R.id.third_hbsag);
        rg8 = (RadioGroup) findViewById(R.id.third_blood_group);
        third_rbs = (EditText) findViewById(R.id.third_rbs);

        rg1 = (RadioGroup) findViewById(R.id.third_trimester_complaints);
        selectedRadioButton = (RadioButton) findViewById(R.id.third_trimester_complaints_yes);
        //opening db
        database = openOrCreateDatabase("gynaecology", Context.MODE_PRIVATE, null);

        //creating table if doesn't exist
        database.execSQL("CREATE TABLE IF NOT EXISTS third_trimester(" + table_query1 + ")");
        database.execSQL("CREATE TABLE IF NOT EXISTS investigations(" + table_query2 + ")");
    }

    @Override
    public void onBackPressed() { }

    public void onProceed(View view) {
        onclickAssign2();
        if (ValidationSuccess()) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
            String format = simpleDateFormat.format(new Date());
            String insert_query1 = "'" + id.toString().trim() + "'," +
                    "'" + pain + "'," +
                    "'" + leak + "'," +
                    "'" + bleed + "'," +
                    "'" + foet + "'," +
                    "'" + pi + "'," +
                    "'" + iront + "'," +
                    "'" + calcium + "'," +
                    "'" + third_other_box.getText().toString().trim() + "'," +
                    "'" + "" + "'," +
                    "'" + "No" + "'," +
                    "'" + format.trim() + "'";
            String insert_query2 = "'" + id.toString().trim() + "'," +
                    "'" + trimesterNo + "'," +
                    "'" + third_hb.getText().toString().trim() + "'," +
                    "'" + bgrt + "'," +
                    "'" + a + "'," +
                    "'" + s + "'," +
                    "'" + s + "'," +
                    "'" + m + "'," +
                    "'" + vdrl + "'," +
                    "'" + hiv + "'," +
                    "'" + third_rbs.getText().toString().trim() + "'," +
                    "'" + e2.getText().toString().trim() + "'," +
                    "'" + "No" + "'," +
                    "'" + format.trim() + "'";
            System.out.println("InsertQuery:" + insert_query1);
            System.out.println("InsertQuery:" + insert_query2);
            //inserting into database
            database.execSQL("INSERT INTO third_trimester VALUES (" + insert_query1 + ")");
            database.execSQL("INSERT INTO investigations VALUES (" + insert_query2 + ")");
            Toast.makeText(getApplicationContext(), "Successful", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(getApplicationContext(), obstetric_score_past_history.class);
            startActivity(intent);
        } else {
            Toast.makeText(getApplicationContext(), "Please check the details", Toast.LENGTH_LONG).show();
        }
    }

    private boolean ValidationSuccess() {

        boolean check = true;
        StringBuilder errMsg = new StringBuilder("");

        if (third_hb.getText().toString().equalsIgnoreCase("")) {
            third_hb.setError("Please enter a value");
            check = false;
        }

        if (Integer.parseInt(third_hb.getText().toString()) > 100) {
            third_hb.setError("Exceeds limit! Please enter a valid percentage");
            return false;
        }

        if (third_rbs.getText().toString().equalsIgnoreCase("")) {
            third_hb.setError("Please enter a value");
            check = false;
        }

        if (rg1.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg2.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg3.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg4.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg5.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg6.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg7.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg8.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (selectedRadioButton.isChecked()) {
            third_other = (CheckBox) findViewById(R.id.third_other);
            third_other_box = (EditText) findViewById(R.id.third_other_box);

            if (!(abdomen.isChecked() || leak_piv.isChecked() || bleed_piv.isChecked() || third_pih.isChecked() || foetal.isChecked() || third_iron.isChecked() || third_other.isChecked() || third_calcium.isChecked())) {
                abdomen.setError("Please select an option");
                check = false;
            } else if (third_other.isChecked() && third_other_box.getText().toString().equalsIgnoreCase("")) {
                third_other.setError("Please enter a value");
                check = false;
            }
        }
        return check;
    }

    public void onclickAssign(View view) {
        b1 = (RadioButton) findViewById(R.id.third_blood_group_A_plus);
        b2 = (RadioButton) findViewById(R.id.third_blood_group_A_minus);
        b3 = (RadioButton) findViewById(R.id.third_blood_group_B_plus);
        b4 = (RadioButton) findViewById(R.id.third_blood_group_B_minus);
        b5 = (RadioButton) findViewById(R.id.third_blood_group_O_plus);
        b6 = (RadioButton) findViewById(R.id.third_blood_group_O_minus);
        b7 = (RadioButton) findViewById(R.id.third_blood_group_AB_plus);
        b8 = (RadioButton) findViewById(R.id.third_blood_group_AB_minus);
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();
        // Check which radio button was clicked
        switch (view.getId()) {
            case R.id.first_blood_group_A_plus:
                if (checked)
                    bgrt = "A+";
                break;
            case R.id.first_blood_group_A_minus:
                if (checked)
                    bgrt = "A-";
                break;
            case R.id.first_blood_group_B_plus:
                if (checked)
                    bgrt = "B+";
                break;
            case R.id.first_blood_group_B_minus:
                if (checked)
                    bgrt = "B-";
                break;
            case R.id.first_blood_group_O_plus:
                if (checked)
                    bgrt = "O+";
                break;
            case R.id.first_blood_group_O_minus:
                if (checked)
                    bgrt = "O-";
                break;
            case R.id.first_blood_group_AB_plus:
                if (checked)
                    bgrt = "AB+";
                break;
            case R.id.first_blood_group_AB_minus:
                if (checked)
                    bgrt = "AB-";
                break;
        }
    }

    public void onclickAssign2() {
        e2 = (EditText) findViewById(R.id.third_trimester_others);
        abdomen = (CheckBox) findViewById(R.id.abdomen);
        bleed_piv = (CheckBox) findViewById(R.id.third_bleeding_piv);
        leak_piv = (CheckBox) findViewById(R.id.leak_piv);
        third_pih = (CheckBox) findViewById(R.id.third_pih);
        third_calcium = (CheckBox) findViewById(R.id.third_calcium);
        third_iron = (CheckBox) findViewById(R.id.third_iron);
        third_other = (CheckBox) findViewById(R.id.third_other);
        third_other_box = (EditText) findViewById(R.id.third_other_box);
        if (selectedRadioButton.isChecked()) {
            if (abdomen.isChecked()) {
                pain = "Yes";
            }
            else
            {
                pain="No";
            }
            if (leak_piv.isChecked()) {
                leak = "Yes";
            }
            else
            {
                leak="No";
            }
            if (bleed_piv.isChecked()) {
                bleed = "Yes";
            }
            if (third_pih.isChecked()) {
                pi = "Yes";

            }
            else
            {
                pi="No";
            }
            if (third_iron.isChecked()) {
                iront = "Yes";
            }
            else
            {
                iront="No";
            }
            if (foetal.isChecked()) {
                foet = "Yes";
            }
            else
            {
                foet="No";
            }
            if (third_calcium.isChecked()) {
                calcium = "Yes";
            }
            else
            {
                calcium="No";
            }
            if (third_other.isChecked()) {
                to = third_other_box.getText().toString();
            } else {
                to = "No";
            }
        }
    }

    public void click(View view) {
        abdomen.setVisibility(View.VISIBLE);
        leak_piv.setVisibility(View.VISIBLE);
        bleed_piv.setVisibility(View.VISIBLE);
        third_pih.setVisibility(View.VISIBLE);
        foetal.setVisibility(View.VISIBLE);
        third_iron.setVisibility(View.VISIBLE);
        third_other.setVisibility(View.VISIBLE);
        third_calcium.setVisibility(View.VISIBLE);
    }

    public void click1(View view) {
        third_other_box.setVisibility(View.GONE);
        abdomen.setVisibility(View.GONE);
        leak_piv.setVisibility(View.GONE);
        bleed_piv.setVisibility(View.GONE);
        third_pih.setVisibility(View.GONE);
        foetal.setVisibility(View.GONE);
        third_iron.setVisibility(View.GONE);
        third_other.setVisibility(View.GONE);
        third_calcium.setVisibility(View.GONE);
    }

    public void click3(View view) {
        third_other_box = (EditText) findViewById(R.id.third_other_box);
        third_other_box.setVisibility(View.VISIBLE);
    }

    public void onclickAssign3(View view) {
        a1 = (RadioButton) findViewById(R.id.albumin_normal);
        a2 = (RadioButton) findViewById(R.id.albumin_abnormal);
        s1 = (RadioButton) findViewById(R.id.sugar_normal);
        s2 = (RadioButton) findViewById(R.id.sugar_abnormal);
        m1 = (RadioButton) findViewById(R.id.microscopy_normal);
        m2 = (RadioButton) findViewById(R.id.microscopy_abnormal);
        v1 = (RadioButton) findViewById(R.id.vdrl_reactive);
        v2 = (RadioButton) findViewById(R.id.vdrl_non_reactive);
        h1 = (RadioButton) findViewById(R.id.hiv_reactive);
        h2 = (RadioButton) findViewById(R.id.hiv_non_reactive);
        hbs1 = (RadioButton) findViewById(R.id.hbsag_reactive);
        hbs2 = (RadioButton) findViewById(R.id.hbsag_non_reactive);
        third_rbs = (EditText) findViewById(R.id.third_rbs);
        boolean checked = ((RadioButton) view).isChecked();
        switch(view.getId()) {
            case R.id.albumin_normal:
                if(checked)
                {
                    a="Normal";
                }
                break;
            case R.id.sugar_normal:
                if(checked)
                {
                    s="Normal";
                }
                break;
            case R.id.microscopy_normal:
                if(checked)
                {
                    m="Normal";
                }
                break;
            case R.id.vdrl_reactive:
                if(checked)
                {
                    vdrl="Reactive";
                }
                break;
            case R.id.hiv_reactive:
                if(checked)
                {
                    hiv="Reactive";
                }
                break;
            case R.id.hbsag_reactive:
                if(checked)
                {
                    hbsag="Reactive";
                }
                break;
            case R.id.albumin_abnormal:
                if(checked)
                {
                    a="Abnormal";
                }
                break;
            case R.id.sugar_abnormal:
                if(checked)
                {
                    s="Abnormal";
                }
                break;
            case R.id.microscopy_abnormal:
                if(checked)
                {
                    m="Abnormal";
                }
                break;
            case R.id.vdrl_non_reactive:
                if(checked)
                {
                    vdrl="Non Reactive";
                }
                break;
            case R.id.hiv_non_reactive:
                if(checked)
                {
                    hiv="Non Reactive";
                }
                break;
            case R.id.hbsag_non_reactive:
                if(checked)
                {
                    hbsag="Non Reactive";
                }
                break;
        }
    }
}
