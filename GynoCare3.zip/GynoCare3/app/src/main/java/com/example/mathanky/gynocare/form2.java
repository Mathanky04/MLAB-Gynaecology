package com.example.mathanky.gynocare;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class form2 extends AppCompatActivity {

    private static TextView btnNext2;
    EditText e1,e2;
    EditText lmp, edd, gestation, corrected;
    RadioGroup rg1;
    RadioButton selectedRadioButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.form2);

        lmp = (EditText)findViewById(R.id.LMP);
        edd = (EditText)findViewById(R.id.EDD);
        gestation = (EditText)findViewById(R.id.gestation);

        lmp.setVisibility(View.GONE);
        edd.setVisibility(View.GONE);
        gestation.setVisibility(View.GONE);

        btnNext2=(TextView)findViewById(R.id.next_page2);
        onButton();
    }

    public void onButton()
    {
        btnNext2=(TextView) findViewById(R.id.next_page2);
        btnNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ValidationSuccess()){
                    onBtnNext2();
                }
            }
        });
    }

    private boolean ValidationSuccess(){

        boolean check=true;
        StringBuilder errMsg = new StringBuilder("");

        e1=(EditText)findViewById(R.id.amenorrhea_month_box);
        e2=(EditText)findViewById(R.id.amenorrhea_day_box);
        rg1=(RadioGroup)findViewById(R.id.G_lmp);
        selectedRadioButton = (RadioButton)findViewById(R.id.G_lmp_yes);
        corrected=(EditText)findViewById(R.id.corrected_EDD);

        if (e1.getText().toString().equalsIgnoreCase("")){
            e1.setError("Please enter a value");
            check=false;
        }

        if (e2.getText().toString().equalsIgnoreCase("")){
            e2.setError("Please enter a value");
            check=false;
        }

        if (Integer.parseInt(e1.getText().toString())>10){
            e1.setError("Exceeds limit!");
            return false;
        }

        if (Integer.parseInt(e2.getText().toString())>31){
            e2.setError("Exceeds limit!");
            return false;
        }

        if (rg1.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if(selectedRadioButton.isChecked())
        {
            lmp = (EditText)findViewById(R.id.LMP);
            edd = (EditText)findViewById(R.id.EDD);

            if (lmp.getText().toString().equalsIgnoreCase("")){
                lmp.setError("Please enter LMP");
                check=false;
            }

            if (edd.getText().toString().equalsIgnoreCase("")){
                e2.setError("Please enter EDD");
                check=false;
            }

        }

        if (corrected.getText().toString().equalsIgnoreCase("")){
            corrected.setError("Please enter the corrected EDD");
            check=false;
        }

        return check;
    }

    public void onBtnNext2()
    {

        btnNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent("com.example.mathanky.gynocare.form3");
                startActivity(intent);
            }
        });
    }

    public void click(View view)
    {
        lmp = (EditText)findViewById(R.id.LMP);
        edd = (EditText)findViewById(R.id.EDD);
        gestation = (EditText)findViewById(R.id.gestation);

        lmp.setVisibility(View.VISIBLE);
        edd.setVisibility(View.VISIBLE);
        gestation.setVisibility(View.VISIBLE);

    }

    public void click1(View view)
    {
        lmp = (EditText)findViewById(R.id.LMP);
        edd = (EditText)findViewById(R.id.EDD);
        gestation = (EditText)findViewById(R.id.gestation);

        lmp.setVisibility(View.GONE);
        edd.setVisibility(View.GONE);
        gestation.setVisibility(View.GONE);

    }


}
