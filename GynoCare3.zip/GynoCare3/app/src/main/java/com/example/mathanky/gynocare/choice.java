package com.example.mathanky.gynocare;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class choice extends AppCompatActivity {

    private static Button btno, btng;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.choice);
        btno=(Button)findViewById(R.id.button_o);
        btng=(Button)findViewById(R.id.button_g);
        onBtnO();
        onBtnG();
    }

    public void onBtnO()
    {
        btno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String d1=getIntent().getExtras().getString("doc_name");
                String d2=getIntent().getExtras().getString("doe");
                Intent intent = new Intent("com.example.mathanky.gynocare.form1");
                intent.putExtra("doc_name",d1);
                intent.putExtra("doe",d2);
                startActivity(intent);
            }
        });
    }

    public void onBtnG()
    {
        btng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent("com.example.mathanky.gynocare.form10");
                startActivity(intent);
            }
        });
    }
}
