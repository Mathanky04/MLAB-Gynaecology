package com.example.mathanky.gynocare;


/**
 * Created by usha on 7/25/2016.
 */

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class form3 extends AppCompatActivity {

    private static TextView btnNext2;
    EditText e1,e2;
    EditText drug_box, other_box, hb, rbs;
    RadioGroup rg1, rg2, rg3, rg4, rg5, rg6, rg7, rg8;
    RadioButton selectedRadioButton;
    CheckBox hyperemesis, micturition, PIV, radiation, fever, folic, drug, other;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.form3);

        hyperemesis = (CheckBox) findViewById(R.id.hyperemesis);
        micturition = (CheckBox) findViewById(R.id.micturition);
        PIV = (CheckBox) findViewById(R.id.PIV);
        radiation = (CheckBox) findViewById(R.id.radiation);
        fever = (CheckBox) findViewById(R.id.fever);
        folic = (CheckBox) findViewById(R.id.folic);

        drug = (CheckBox) findViewById(R.id.drug);
        drug_box = (EditText)findViewById(R.id.drug_box);

        other = (CheckBox) findViewById(R.id.other);
        other_box = (EditText)findViewById(R.id.other_box);

        drug_box.setVisibility(View.GONE);
        other_box.setVisibility(View.GONE);

        hyperemesis.setVisibility(View.GONE);
        micturition.setVisibility(View.GONE);
        PIV.setVisibility(View.GONE);
        drug_box.setVisibility(View.GONE);
        other_box.setVisibility(View.GONE);
        radiation.setVisibility(View.GONE);
        fever.setVisibility(View.GONE);
        folic.setVisibility(View.GONE);
        drug.setVisibility(View.GONE);
        other.setVisibility(View.GONE);


        btnNext2=(TextView)findViewById(R.id.next_page3);
        onButton();
    }

    public void onButton()
    {
        btnNext2=(TextView) findViewById(R.id.next_page3);
        btnNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ValidationSuccess()){
                    onBtnNext2();
                }
            }
        });
    }

    private boolean ValidationSuccess(){

        boolean check=true;
        StringBuilder errMsg = new StringBuilder("");

        hb = (EditText)findViewById(R.id.hb) ;
        rg2 = (RadioGroup)findViewById(R.id.albumin);
        rg3 = (RadioGroup)findViewById(R.id.sugar);
        rg4 = (RadioGroup)findViewById(R.id.microscopy);
        rg5 = (RadioGroup)findViewById(R.id.vdrl);
        rg6 = (RadioGroup)findViewById(R.id.hiv);
        rg7 = (RadioGroup)findViewById(R.id.hbsag);
        rg8 = (RadioGroup)findViewById(R.id.first_blood_group);
        rbs = (EditText)findViewById(R.id.rbs);

        rg1=(RadioGroup)findViewById(R.id.first_trimester_complaints);
        selectedRadioButton = (RadioButton)findViewById(R.id.first_trimester_complaints_yes);


        if (hb.getText().toString().equalsIgnoreCase("")){
            hb.setError("Please enter a value");
            check=false;
        }

        if (rbs.getText().toString().equalsIgnoreCase("")){
            hb.setError("Please enter a value");
            check=false;
        }

        if (rg1.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg2.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg3.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg4.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg5.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg6.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg7.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg8.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }


        if(selectedRadioButton.isChecked())
        {
            hyperemesis = (CheckBox) findViewById(R.id.hyperemesis);
            micturition = (CheckBox) findViewById(R.id.micturition);
            PIV = (CheckBox) findViewById(R.id.PIV);
            radiation = (CheckBox) findViewById(R.id.radiation);
            fever = (CheckBox) findViewById(R.id.fever);
            folic = (CheckBox) findViewById(R.id.folic);

            drug = (CheckBox) findViewById(R.id.drug);
            drug_box = (EditText)findViewById(R.id.drug_box);

            other = (CheckBox) findViewById(R.id.other);
            other_box = (EditText)findViewById(R.id.other_box);

            if (!(hyperemesis.isChecked() || micturition.isChecked() || PIV.isChecked() || radiation.isChecked() || fever.isChecked() || folic.isChecked() || drug.isChecked() || other.isChecked())){
                hyperemesis.setError("Please select an option");
                check=false;
            }

            else if(drug.isChecked()&& drug_box.getText().toString().equalsIgnoreCase("")){
                drug.setError("Please enter  a value");
                check=false;
            }

            else if(other.isChecked()&& other_box.getText().toString().equalsIgnoreCase("")){
                drug.setError("Please enter a value");
                check=false;
            }

        }


        return check;
    }

    public void onBtnNext2()
    {

        btnNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent("com.example.mathanky.gynocare2.form4");
                startActivity(intent);
            }
        });
    }

    public void click(View view)
    {
        hyperemesis = (CheckBox) findViewById(R.id.hyperemesis);
        micturition = (CheckBox) findViewById(R.id.micturition);
        PIV = (CheckBox) findViewById(R.id.PIV);
        radiation = (CheckBox) findViewById(R.id.radiation);
        fever = (CheckBox) findViewById(R.id.fever);
        folic = (CheckBox) findViewById(R.id.folic);
        drug = (CheckBox) findViewById(R.id.drug);
        other = (CheckBox) findViewById(R.id.other);
        hyperemesis.setVisibility(View.VISIBLE);
        micturition.setVisibility(View.VISIBLE);
        PIV.setVisibility(View.VISIBLE);
        radiation.setVisibility(View.VISIBLE);
        fever.setVisibility(View.VISIBLE);
        folic.setVisibility(View.VISIBLE);
        drug.setVisibility(View.VISIBLE);
        other.setVisibility(View.VISIBLE);

    }

    public void click2(View view)
    {
        drug_box = (EditText)findViewById(R.id.drug_box);
        drug_box.setVisibility(View.VISIBLE);

    }

    public void click3(View view)
    {
        other_box = (EditText)findViewById(R.id.other_box);
        other_box.setVisibility(View.VISIBLE);

    }
    public void click1(View view)
    {
        hyperemesis = (CheckBox) findViewById(R.id.hyperemesis);
        micturition = (CheckBox) findViewById(R.id.micturition);
        PIV = (CheckBox) findViewById(R.id.PIV);
        radiation = (CheckBox) findViewById(R.id.radiation);
        fever = (CheckBox) findViewById(R.id.fever);
        folic = (CheckBox) findViewById(R.id.folic);

        drug = (CheckBox) findViewById(R.id.drug);
        drug_box = (EditText)findViewById(R.id.drug_box);

        other = (CheckBox) findViewById(R.id.other);
        other_box = (EditText)findViewById(R.id.other_box);

        drug_box.setVisibility(View.GONE);
        other_box.setVisibility(View.GONE);

        hyperemesis.setVisibility(View.GONE);
        micturition.setVisibility(View.GONE);
        PIV.setVisibility(View.GONE);
        radiation.setVisibility(View.GONE);
        fever.setVisibility(View.GONE);
        folic.setVisibility(View.GONE);
        drug.setVisibility(View.GONE);
        other.setVisibility(View.GONE);

    }


}
