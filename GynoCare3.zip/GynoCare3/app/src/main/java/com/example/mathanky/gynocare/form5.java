package com.example.mathanky.gynocare;


/**
 * Created by Shruthi on 7/25/2016.
 */

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class form5 extends AppCompatActivity {

    private static TextView btnNext2;
    EditText e1,e2,e3,e4,e5,e6,e7, e8, e9;
    RadioGroup rg1, rg2, rg3, rg4;
    RadioButton selectedRadioButton;
    CheckBox antenatal, intrapartum, postpartum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.form3second);

        antenatal = (CheckBox) findViewById(R.id.antenatal);
        intrapartum = (CheckBox) findViewById(R.id.intrapartum);
        postpartum = (CheckBox) findViewById(R.id.postpartum);

        antenatal.setVisibility(View.GONE);
        intrapartum.setVisibility(View.GONE);
        postpartum.setVisibility(View.GONE);

        btnNext2=(TextView)findViewById(R.id.next_page5);
        onButton();
    }

    public void onButton()
    {
        btnNext2=(TextView) findViewById(R.id.next_page5);
        btnNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ValidationSuccess()){
                    onBtnNext2();
                }
            }
        });
    }

    private boolean ValidationSuccess(){

        boolean check=true;
        StringBuilder errMsg = new StringBuilder("");


        rg2 = (RadioGroup)findViewById(R.id.mode_of_delivery);
        rg3 = (RadioGroup)findViewById(R.id.status);
        rg4 = (RadioGroup)findViewById(R.id.gender);

        e1 = (EditText)findViewById(R.id.G_box);
        e2 = (EditText)findViewById(R.id.P_box);
        e3 = (EditText)findViewById(R.id.A_box);
        e4 = (EditText)findViewById(R.id.L_box);
        e5 = (EditText)findViewById(R.id.D_box);
        e6 = (EditText)findViewById(R.id.term);
        e7 = (EditText)findViewById(R.id.baby_weight);
        e8 = (EditText)findViewById(R.id.baby_age_days);
        e9 = (EditText)findViewById(R.id.baby_age_months);


        rg1=(RadioGroup)findViewById(R.id.complications);
        selectedRadioButton = (RadioButton)findViewById(R.id.complications_yes);


        if (e1.getText().toString().equalsIgnoreCase("")){
            e1.setError("Please enter a value");
            check=false;
        }

        if (e2.getText().toString().equalsIgnoreCase("")){
            e2.setError("Please enter a value");
            check=false;
        }

        if (e3.getText().toString().equalsIgnoreCase("")){
            e3.setError("Please enter a value");
            check=false;
        }

        if (e4.getText().toString().equalsIgnoreCase("")){
            e4.setError("Please enter a value");
            check=false;
        }

        if (e5.getText().toString().equalsIgnoreCase("")){
            e5.setError("Please enter a value");
            check=false;
        }

        if (e6.getText().toString().equalsIgnoreCase("")){
            e6.setError("Please enter a value");
            check=false;
        }

        if (e7.getText().toString().equalsIgnoreCase("")){
            e7.setError("Please enter a value");
            check=false;
        }

        if (e8.getText().toString().equalsIgnoreCase("")){
            e8.setError("Please enter a value");
            check=false;
        }

        if (Integer.parseInt(e8.getText().toString())>31){
            e8.setError("Exceeds limit! Please enter a valid number of days less than 31");
            return false;
        }


        if (e9.getText().toString().equalsIgnoreCase("")){
            e9.setError("Please enter a value");
            check=false;
        }



        if (rg1.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg2.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg3.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg4.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if(selectedRadioButton.isChecked())
        {
            antenatal = (CheckBox) findViewById(R.id.antenatal);
            intrapartum = (CheckBox) findViewById(R.id.intrapartum);
            postpartum = (CheckBox) findViewById(R.id.postpartum);

            if (!(antenatal.isChecked() || intrapartum.isChecked() || postpartum.isChecked())){
                antenatal.setError("Please select an option");
                check=false;
            }

        }


        return check;
    }

    public void onBtnNext2()
    {

        btnNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent("com.example.mathanky.gynocare.form6");
                startActivity(intent);
            }
        });
    }

    public void click(View view)
    {
        antenatal = (CheckBox) findViewById(R.id.antenatal);
        intrapartum = (CheckBox) findViewById(R.id.intrapartum);
        postpartum = (CheckBox) findViewById(R.id.postpartum);

        antenatal.setVisibility(View.VISIBLE);
        intrapartum.setVisibility(View.VISIBLE);
        postpartum.setVisibility(View.VISIBLE);
    }

    public void click1(View view)
    {
        antenatal = (CheckBox) findViewById(R.id.antenatal);
        intrapartum = (CheckBox) findViewById(R.id.intrapartum);
        postpartum = (CheckBox) findViewById(R.id.postpartum);

        antenatal.setVisibility(View.GONE);
        intrapartum.setVisibility(View.GONE);
        postpartum.setVisibility(View.GONE);
    }


}
