package com.example.mathanky.gynocare;


/**
 * Created by Shruthi on 7/25/2016.
 */

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class form13 extends AppCompatActivity {

    private static TextView btnNext2;
    EditText e1,e2,e3,e4,e5,e6,e7, e8, e9;
    RadioGroup rg1, rg2, rg3, rg4, rg5, rg6;
    RadioButton selectedRadioButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.form13);

        e1 = (EditText)findViewById(R.id.allergy_box) ;
        e1.setVisibility(View.GONE);

        btnNext2=(TextView)findViewById(R.id.next_page13);
        onButton();
    }

    public void onButton()
    {
        btnNext2=(TextView) findViewById(R.id.next_page13);
        btnNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ValidationSuccess()){
                    onBtnNext2();
                }
            }
        });
    }

    private boolean ValidationSuccess(){

        boolean check=true;
        StringBuilder errMsg = new StringBuilder("");


        rg2 = (RadioGroup)findViewById(R.id.sleep);
        rg3 = (RadioGroup)findViewById(R.id.allergy);

        e1 = (EditText)findViewById(R.id.appetite_box);
        e2 = (EditText)findViewById(R.id.micturition_box);
        e3 = (EditText)findViewById(R.id.bowel_box);
        e4 = (EditText)findViewById(R.id.habits_box);


        rg1=(RadioGroup)findViewById(R.id.diet);
        selectedRadioButton = (RadioButton)findViewById(R.id.allergy_yes);


        if (e1.getText().toString().equalsIgnoreCase("")){
            e1.setError("Please enter a value");
            check=false;
        }

        if (e2.getText().toString().equalsIgnoreCase("")){
            e2.setError("Please enter a value");
            check=false;
        }

        if (e3.getText().toString().equalsIgnoreCase("")){
            e3.setError("Please enter a value");
            check=false;
        }

        if (e4.getText().toString().equalsIgnoreCase("")){
            e4.setError("Please enter a value");
            check=false;
        }

        if (rg1.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg2.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg3.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if(selectedRadioButton.isChecked())
        {
            e1 = (EditText)findViewById(R.id.allergy_box) ;
            if (e1.getText().toString().equalsIgnoreCase("")){
                e1.setError("Please enter a value");
                check=false;
            }
        }


        return check;
    }

    public void onBtnNext2()
    {

        btnNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent("com.example.mathanky.gynocare.form14");
                startActivity(intent);
            }
        });
    }

    public void click(View view)
    {
        e1 = (EditText)findViewById(R.id.allergy_box) ;
        e1.setVisibility(View.VISIBLE);

    }

    public void click1(View view)
    {
        e1 = (EditText)findViewById(R.id.allergy_box) ;
        e1.setVisibility(View.GONE);

    }


}
