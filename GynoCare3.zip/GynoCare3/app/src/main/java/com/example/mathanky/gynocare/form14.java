package com.example.mathanky.gynocare;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class form14 extends AppCompatActivity {

    private static Button btnNext14;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.form14);
        btnNext14=(Button)findViewById(R.id.next_page14);
        onBtnNext14();
    }
    public void onBtnNext14()
    {
        btnNext14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent("com.example.mathanky.gynocare.form15");
                startActivity(intent);
            }
        });
    }
}
