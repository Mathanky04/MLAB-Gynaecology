package com.example.mathanky.gynocare;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME="Gynocare";
    public static final String TABLE0="doctor_table";
    public static final String COL0="doctor_name";
    public static final String COL177= "date_of_examination1";
    public static final String TABLE1="general_information";
    public static final String COL1="name";
    public static final String COL2= "date_of_examination";
    public static final String COL3="patient_id";
    public static final String COL4="age";
    public static final String COL5="wife_of";
    public static final String COL6="occupation";
    public static final String COL7="address";
    public static final String COL8="mobile_number";
    public static final String COL9="landline_number";
    public static final String TABLE2="obstetric_information";
    public static final String COL10="history_of_amenorrhea_months";
    public static final String COL11="history_of_amenorrhea_days";
    public static final String COL12="lmp";
    public static final String COL13="edd";
    public static final String COL14="gestational_age_in_weeks";
    public static final String COL15="corrected_edd";      
    public static final String COL16="any_complaints1";
    public static final String TABLE3="first_trimester";
    public static final String COL17="hyperemesis";
    public static final String COL18="burning_micturition";
    public static final String COL19="bleeding_piv_spotting_piv";
    public static final String COL20="radiation_exposure";
    public static final String COL21="fever_with_rash";
    public static final String COL22="folic_acid_intake";
    public static final String COL23="other_drug_intake";
    public static final String COL24="others1";
    public static final String COL25="scan";
    public static final String TABLE4="second_trimester";
    public static final String COL26="quickening";
    public static final String COL27="history_of_bleeding_piv";
    public static final String COL28="leak_piv1";
    public static final String COL29="pih_history1";
    public static final String COL30="tt";
    public static final String COL31="iron_tablets1";
    public static final String COL32="calcium_tablets1";
    public static final String COL33="others2";
    public static final String COL34="anomaly_scan";
    public static final String TABLE5="third_trimester";
    public static final String COL35="pain_in_abdomen";
    public static final String COL36="leak_piv2";
    public static final String COL37="bleeding_piv";
    public static final String COL38="foetal_movements";
    public static final String COL39="pih_history2";
    public static final String COL40="iron_tablets2";
    public static final String COL41="calcium_tablets2";
    public static final String COL42="others3";
    public static final String COL43="growth_scan";
    public static final String TABLE6="investigations";
    public static final String COL178="trimester_number";
    public static final String COL44="hb";
    public static final String COL45="blood_grouping_rh_typing";
    public static final String COL46="albumin";
    public static final String COL47="sugar";
    public static final String COL48="microscopy";
    public static final String COL49="vdrl";
    public static final String COL50="hiv_status";
    public static final String COL51="hbsag";
    public static final String COL52="rbs";
    public static final String COL53="others4";
    public static final String TABLE7="obstetric_score";
    public static final String COL54="g";
    public static final String COL55="p";
    public static final String COL56="a";
    public static final String COL57="l";
    public static final String COL58="d";
    public static final String TABLE8="past_obstetric_history";
    public static final String COL59="pregnancy_order";
    public static final String COL60="term_preterm";
    public static final String COL61="mode_of_delivery";
    public static final String COL62="antenatal";
    public static final String COL63="intrapartum";
    public static final String COL64="postpartum";
    public static final String COL65="alive_dead";
    public static final String COL66="gender";
    public static final String COL67="baby_weight";
    public static final String COL68="present_age_months";
    public static final String COL69="present_age_days";
    public static final String TABLE9="history_table";
    public static final String COL70="menstrual_history";
    public static final String COL71="contraceptive_history";
    public static final String COL72="past_history";
    public static final String COL73="family_history";
    public static final String TABLE10="personal_history";
    public static final String COL74="diet";
    public static final String COL75="sleep";
    public static final String COL76="addictive_habits";
    public static final String COL77="allergies_known";
    public static final String TABLE11="general_physical_examination";
    public static final String COL78="height";
    public static final String COL79="weight";
    public static final String COL80="bmi_pre_pregnancy";
    public static final String COL81="pr";
    public static final String COL82="bp";
    public static final String COL83="temp";
    public static final String COL84="breasts";
    public static final String COL85="nipples";
    public static final String COL86="thyroid";
    public static final String COL87="spine";
    public static final String COL88="icterus";
    public static final String COL89="pallor";
    public static final String COL90="edema";
    public static final String COL91="cyanosis";
    public static final String COL92="clubbing";
    public static final String COL93="lymphadenopathy";
    public static final String TABLE12="systemic_examination";
    public static final String COL94="cvs";
    public static final String COL95="rs";
    public static final String COL96="cns";
    public static final String COL97="uterine_size";
    public static final String COL98="presentation";
    public static final String COL99="fhs";
    public static final String COL100="liquor";
    public static final String COL101="previous_scar";
    public static final String TABLE13="gynaec_complaints";
    public static final String COL102="gynaec_chief_complaints";
    public static final String COL103= "gynaec_lmp";
    public static final String COL104="gynaec_history_of_present_illness";
    public static final String COL105="gynaec_menstrual_history";
    public static final String TABLE14="gynaec_obstetric_history";
    public static final String COL106="gynaec_married_life";
    public static final String COL107="gynaec_p";
    public static final String COL108="gynaec_a";
    public static final String COL109="gynaec_l";
    public static final String TABLE15="gynaec_past_history";
    public static final String COL110="gynaec_diabetes1";
    public static final String COL111="gynaec_hypertension1";
    public static final String COL112="gynaec_tb1";
    public static final String COL113="gynaec_epilepsy";
    public static final String COL114="gynaec_cardiac_disease";
    public static final String COL115="gynaec_renal_disease";
    public static final String COL116="gynaec_veneral_disease";
    public static final String COL117="gynaec_blood_transfusion";
    public static final String COL118="gynaec_past_surgeries";
    public static final String COL119="gynaec_others5";
    public static final String TABLE16="gynaec_family_history";
    public static final String COL120="gynaec_diabetes2";
    public static final String COL121="gynaec_hypertension2";
    public static final String COL122="gynaec_tb2";
    public static final String COL123="gynaec_malignancy";
    public static final String COL124="gynaec_others6";
    public static final String TABLE17="gynaec_personal_history";
    public static final String COL125="gynaec_diet";
    public static final String COL126="gynaec_appetite";
    public static final String COL127="gynaec_sleep";
    public static final String COL128="gynaec_micturition";
    public static final String COL129="gynaec_bowel";
    public static final String COL130="gynaec_habits";
    public static final String COL131="gynaec_allergy_history";
    public static final String TABLE18="gynaec_physical_examination";
    public static final String COL132="gynaec_height";
    public static final String COL133="gynaec_weight";
    public static final String COL134="gynaec_bmi";
    public static final String COL135="gynaec_temp";
    public static final String COL136="gynaec_pr";
    public static final String COL137="gynaec_bp";
    public static final String COL138="gynaec_thyroid";
    public static final String COL139="gynaec_breasts";
    public static final String COL140="gynaec_spine";
    public static final String COL141="gynaec_pallor";
    public static final String COL142="gynaec_icterus";
    public static final String COL143="gynaec_cyanosis";
    public static final String COL144="gynaec_clubbing";
    public static final String COL145="gynaec_lymphadenopathy";
    public static final String COL146="gynaec_edema";
    public static final String TABLE19="gynaec_systemic_examination";
    public static final String COL147="gynaec_cvs";
    public static final String COL148="gynaec_rs";
    public static final String COL149="gynaec_cns";
    public static final String COL150="gynaec_inspection";
    public static final String COL151="gynaec_palpation";
    public static final String COL152="gynaec_percussion";
    public static final String COL153="gynaec_auscultation";
    public static final String COL154="gynaec_local_examination";
    public static final String COL155="gynaec_speculum_examination";
    public static final String COL156="gynaec_bimanual_examination";
    public static final String COL157="gynaec_rectal_examination";
    public static final String COL158="gynaec_provisional_diagnosis";
    public static final String TABLE20 ="gynaec_investigations";
    public static final String COL159="gynaec_hb";
    public static final String COL160="gynaec_tc";
    public static final String COL161="gynaec_platelet_count";
    public static final String COL162="gynaec_peripheral_smear";
    public static final String COL163="gynaec_bloood_grouping_rh_typing";
    public static final String COL164="gynaec_albumin";
    public static final String COL165="gynaec_sugar";
    public static final String COL166="gynaec_microscopy";
    public static final String COL167="gynaec_cs";
    public static final String COL168="gynaec_hiv";
    public static final String COL169="gynaec_hbsag";
    public static final String COL170="gynaec_vdrl";
    public static final String COL171="gynaec_rbs";
    public static final String COL172="gynaec_fbs";
    public static final String COL173="gynaec_ppbs";
    public static final String COL174="gynaec_ultrasound";
    public static final String COL175="gynaec_pap_smear";
    public static final String TABLE21="gynaec_care";
    public static final String COL176="gynaec_plan_of_care";
    public static final String COL180="gynaec_advice";
    public static final String COL179="update_status";
    public static final String COL181="timestamp";

    public DBHelper(Context context) {
        super(context,DATABASE_NAME,null,1);
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table "+TABLE1+"(name TEXT NOT NULL, date_of_examination TEXT NOT NULL, patient_id TEXT NOT NULL, wife_of TEXT NOT NULL, occupation TEXT DEFAULT \"Not Specified\",address TEXT DEFAULT \"Not Specified\", mobile_number TEXT NOT NULL, landline_number TEXT DEFAULT \"Not Specified\",update_status TEXT DEFAULT \"No\",timestamp TEXT NOT NULL, primary key(patient_id))");
        sqLiteDatabase.execSQL("create table "+TABLE0+"(doctor_name TEXT NOT NULL, patient_id TEXT NOT NULL, date_of_examination1 TEXT NOT NULL,update_status TEXT DEFAULT \"No\",timestamp TEXT NOT NULL, primary key(doctor_name, patient_id, date_of_examination1), foreign key(patient_id) references general_information(patient_id))");
        sqLiteDatabase.execSQL("create table "+TABLE2+"(patient_id TEXT NOT NULL, history_of_amenorrhea_months TEXT NOT NULL,history_of_amenorrhea_days TEXT NOT NULL,lmp TEXT NOT NULL, edd TEXT NOT NULL, gestational_age TEXT NOT NULL, corrected_edd TEXT NOT NULL, any_complaints1 TEXT DEFAULT \"Not Specified\",update_status TEXT DEFAULT \"No\",timestamp TEXT NOT NULL, primary key(patient_id), foreign key(patient_id) references general_information(patient_id))");
        sqLiteDatabase.execSQL("create table "+TABLE3+"(patient_id TEXT NOT NULL,hyperemesis TEXT DEFAULT \"Not Specified\", burning_micturition TEXT DEFAULT \"Not Specified\",bleeding_piv_spotting_piv TEXT DEFAULT \"Not Specified\",radiation_exposure TEXT DEFAULT \"Not Specified\",fever_with_rash TEXT DEFAULT \"Not Specified\",folic_acid_intake TEXT DEFAULT \"Not Specified\", other_drug_intake TEXT DEFAULT \"Not Specified\",others1 , scan TEXT NOT NULL,update_status TEXT DEFAULT \"No\", timestamp TEXT NOT NULL,primary key(patient_id), foreign key(patient_id) references general_information(patient_id))");
        sqLiteDatabase.execSQL("create table "+TABLE4+"(patient_id TEXT NOT NULL,quickening TEXT DEFAULT \"Not Specified\", history_of_bleeding_piv TEXT DEFAULT \"Not Specified\",leak_piv1 TEXT DEFAULT \"Not Specified\",pih_history1 TEXT DEFAULT \"Not Specified\",tt TEXT DEFAULT \"Not Specified\", iron_tablets1 TEXT DEFAULT \"Not Specified\",calcium_tablets1 TEXT DEFAULT \"Not Specified\", others2 TEXT DEFAULT \"Not Specified\",anomaly_scan TEXT NOT NULL,update_status TEXT DEFAULT \"No\",timestamp TEXT NOT NULL,primary key(patient_id), foreign key(patient_id) references general_information(patient_id))");
        sqLiteDatabase.execSQL("create table "+TABLE5+"(patient_id TEXT NOT NULL,pain_in_abdomen TEXT DEFAULT \"Not Specified\",leak_piv2 TEXT DEFAULT \"Not Specified\",bleeding_piv TEXT DEFAULT \"Not Specified\",foetal_movements TEXT DEFAULT \"Not Specified\",pih_history2 TEXT DEFAULT \"Not Specified\", iron_tablets2 TEXT DEFAULT \"Not Specified\",calcium_tablets2 TEXT DEFAULT \"Not Specified\", others3 TEXT DEFAULT \"Not Specified\",growth_scan TEXT NOT NULL,update_status TEXT DEFAULT \"No\",timestamp TEXT NOT NULL,primary key(patient_id), foreign key(patient_id) references general_information(patient_id))");
        sqLiteDatabase.execSQL("create table "+TABLE6+"(patient_id TEXT NOT NULL,trimester_number TEXT NOT NULL, hb TEXT NOT NULL, blood_grouping_rh_typing TEXT NOT NULL, albumin TEXT NOT NULL, sugar TEXT NOT NULL, microscopy TEXT NOT NULL, vdrl TEXT NOT NULL, hiv_status TEXT NOT NULL, hbsag TEXT NOT NULL, rbs TEXT NOT NULL, others4 TEXT DEFAULT \"Not Specified\", update_status TEXT DEFAULT \"No\",timestamp TEXT NOT NULL,primary key(patient_id, trimester_number), foreign key(patient_id) references general_information(patient_id))");
        sqLiteDatabase.execSQL("create table "+TABLE7+"(patient_id TEXT NOT NULL, g TEXT NOT NULL,p TEXT NOT NULL,a TEXT NOT NULL,l TEXT NOT NULL,d TEXT NOT NULL,timestamp TEXT NOT NULL,primary key(patient_id), foreign key(patient_id) references general_information(patient_id))");
        sqLiteDatabase.execSQL("create table "+TABLE8+"(patient_id TEXT NOT NULL,pregnancy_order TEXT NOT NULL, term_preterm TEXT NOT NULL, mode_of_delivery TEXT NOT NULL, antenatal TEXT DEFAULT \"Not Specified\",intrapartum TEXT DEFAULT \"Not Specified\",postpartum TEXT DEFAULT \"Not Specified\", alive_dead TEXT NOT NULL, gender TEXT NOT NULL, baby_weight TEXT NOT NULL, present_age_months TEXT NOT NULL, present_age_days TEXT NOT NULL,update_status TEXT DEFAULT \"No\", timestamp TEXT NOT NULL,primary key(patient_id,pregnancy_order), foreign key(patient_id) references general_information(patient_id))");
        sqLiteDatabase.execSQL("create table "+TABLE9+"(patient_id TEXT NOT NULL,menstrual_history TEXT NOT NULL, contraceptive_history TEXT NOT NULL, past_history TEXT NOT NULL, family_history TEXT NOT NULL,update_status TEXT DEFAULT \"No\",timestamp TEXT NOT NULL,primary key(patient_id), foreign key(patient_id) references general_information(patient_id))");
        sqLiteDatabase.execSQL("create table "+TABLE10+"(patient_id TEXT NOT NULL,diet TEXT NOT NULL, sleep TEXT NOT NULL, addictive_habits TEXT NOT NULL, allergies_known TEXT NOT NULL,update_status TEXT DEFAULT \"No\",timestamp TEXT NOT NULL, primary key(patient_id), foreign key(patient_id) references general_information(patient_id))");
        sqLiteDatabase.execSQL("create table "+TABLE11+"(patient_id TEXT NOT NULL, height TEXT NOT NULL, weight TEXT NOT NULL, bmi_pre_pregnancy TEXT NOT NULL, pr TEXT NOT NULL, bp TEXT NOT NULL, temp TEXT NOT NULL, breasts TEXT NOT NULL,nipples TEXT NOT NULL,thyroid TEXT NOT NULL,spine TEXT NOT NULL,icterus TEXT NOT NULL,pallor TEXT NOT NULL,edema TEXT NOT NULL, cyanosis TEXT NOT NULL,clubbing TEXT NOT NULL,lymphadenopathy TEXT NOT NULL,update_status TEXT DEFAULT \"No\",timestamp TEXT NOT NULL, primary key(patient_id), foreign key(patient_id) references general_information(patient_id))");
        sqLiteDatabase.execSQL("create table "+TABLE12+"(patient_id TEXT NOT NULL,cvs TEXT NOT NULL, rs TEXT NOT NULL, cns TEXT NOT NULL, uterine_size TEXT NOT NULL, presentation TEXT NOT NULL, fhs TEXT NOT NULL, liquor TEXT NOT NULL, previous_scar TEXT NOT NULL,update_status TEXT DEFAULT \"No\", timestamp TEXT NOT NULL, primary key(patient_id), foreign key(patient_id) references general_information(patient_id))");
        sqLiteDatabase.execSQL("create table "+TABLE13+"(patient_id TEXT NOT NULL,gynaec_chief_complaints TEXT NOT NULL, gynaec_lmp TEXT NOT NULL,gynaec_history_of_present_illness TEXT NOT NULL, gynaec_menstrual_history TEXT NOT NULL,update_status TEXT DEFAULT \"No\", timestamp TEXT NOT NULL,primary key(patient_id), foreign key(patient_id) references general_information(patient_id))");
        sqLiteDatabase.execSQL("create table "+TABLE14+"(patient_id TEXT NOT NULL,gynaec_married_life TEXT NOT NULL, gynaec_p TEXT NOT NULL, gynnaec_a TEXT NOT NULL, gynaec_l TEXT NOT NULL,update_status TEXT DEFAULT \"No\", timestamp TEXT NOT NULL, primary key(patient_id), foreign key(patient_id) references general_information(patient_id))");
        sqLiteDatabase.execSQL("create table "+TABLE15+"(patient_id TEXT NOT NULL,gynaec_diabetes1 TEXT DEFAULT \"Not Specified\", gynaec_hypertension1 TEXT DEFAULT \"Not Specified\",gynaec_tb1 TEXT DEFAULT \"Not Specified\", gynaec_epilepsy TEXT DEFAULT \"Not Specified\",gynaec_cardiac_disease TEXT DEFAULT \"Not Specified\",gynaec_renal_disease TEXT DEFAULT \"Not Specified\",gynaec_veneral_disease TEXT DEFAULT \"Not Specified\",gynaec_blood_transfusion TEXT DEFAULT \"Not Specified\",gynaec_past_surgeries TEXT DEFAULT \"Not Specified\",gynaec_others5 TEXT DEFAULT \"Not Specified\",update_status TEXT DEFAULT \"No\", timestamp TEXT NOT NULL,primary key(patient_id), foreign key(patient_id) references general_information(patient_id))");
        sqLiteDatabase.execSQL("create table "+TABLE16+"(patient_id TEXT NOT NULL,gynaec_diabetes2 TEXT DEFAULT \"Not Specified\",gynaec_hypertension2 TEXT DEFAULT \"Not Specified\",gynaec_tb2 TEXT DEFAULT \"Not Specified\",gynaec_malignancy TEXT DEFAULT \"Not Specified\", gynaec_others6 TEXT DEFAULT \"Not Specified\",update_status TEXT DEFAULT \"No\", timestamp TEXT NOT NULL, primary key(patient_id), foreign key(patient_id) references general_information(patient_id))");
        sqLiteDatabase.execSQL("create table "+TABLE17+"(patient_id TEXT NOT NULL,gynaec_diet TEXT NOT NULL,gynaec_appetite TEXT NOT NULL, gynaec_sleep TEXT NOT NULL, gynaec_micturition TEXT NOT NULL, gynaec_bowel TEXT NOT NULL,gynaec_habits TEXT NOT NULL, gynaec_allergy_history TEXT NOT NULL,update_status TEXT DEFAULT \"No\", timestamp TEXT NOT NULL,primary key(patient_id), foreign key(patient_id) references general_information(patient_id))");
        sqLiteDatabase.execSQL("create table "+TABLE18+"(patient_id TEXT NOT NULL, gynaec_height TEXT NOT NULL, gynaec_weight TEXT NOT NULL, gynaec_bmi TEXT NOT NULL, gynaec_temp TEXT NOT NULL, gynaec_pr TEXT NOT NULL, gynaec_bp TEXT NOT NULL, gynaec_thyroid TEXT NOT NULL, gynaec_breasts TEXT NOT NULL, gynaec_spine TEXT NOT NULL, gynaec_pallor TEXT NOT NULL,  gynaec_icterus TEXT NOT NULL, gynaec_cyanosis TEXT NOT NULL, gynaec_clubbing TEXT NOT NULL, gynaec_lymphadenopathy TEXT NOT NULL, gynaec_edema TEXT NOT NULL,update_status TEXT DEFAULT \"No\", timestamp TEXT NOT NULL,primary key(patient_id), foreign key(patient_id) references general_information(patient_id))");
        sqLiteDatabase.execSQL("create table "+TABLE19+"(patient_id TEXT NOT NULL, gynaec_cvs TEXT NOT NULL, gynaec_rs TEXT NOT NULL, gynaec_cns TEXT NOT NULL, gynaec_inspection TEXT NOT NULL, gynaec_palpation TEXT NOT NULL, gynaec_percussion TEXT NOT NULL, gynaec_auscultation TEXT NOT NULL, gynaec_local_examination TEXT NOT NULL, gynaec_speculum_examination TEXT NOT NULL, gynaec_bimanual_examination TEXT NOT NULL,  gynaec_rectal_examination TEXT NOT NULL, gynaec_provisional_diagnosis TEXT NOT NULL,update_status TEXT DEFAULT \"No\", timestamp TEXT NOT NULL, primary key(patient_id), foreign key(patient_id) references general_information(patient_id))");
        sqLiteDatabase.execSQL("create table "+TABLE20+"(patient_id TEXT NOT NULL, gynaec_hb TEXT NOT NULL, gynaec_tc TEXT NOT NULL, gynaec_platelet_count TEXT NOT NULL, gynaec_peripheral_smear TEXT NOT NULL, gynaec_blood_grouping_rh_typing TEXT NOT NULL, gynaec_albumin TEXT NOT NULL, gynaec_sugar TEXT NOT NULL, gynaec_microscopy TEXT NOT NULL, gynaec_hiv TEXT NOT NULL, gynaec_hbsag TEXT NOT NULL,  gynaec_vdrl TEXT NOT NULL, gynaec_rbs TEXT NOT NULL,gynaec_fbs TEXT NOT NULL,gynaec_ppbs TEXT NOT NULL,gynaec_ultrasound TEXT NOT NULL,gynaec_pap_smear TEXT NOT NULL, update_status TEXT DEFAULT \"No\", timestamp TEXT NOT NULL,primary key(patient_id), foreign key(patient_id) references general_information(patient_id))");
        sqLiteDatabase.execSQL("create table "+TABLE21+"(patient_id TEXT NOT NULL, gynaec_plan_of_care TEXT DEFAULT \"Not SPecified\", gynaec_advice TEXT DEFAULT \"Not Specified\",update_status TEXT DEFAULT \"No\",  timestamp TEXT NOT NULL, primary key(patient_id), foreign key(patient_id) references general_information(patient_id))");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS "+TABLE1);
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS "+TABLE2);
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS "+TABLE3);
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS "+TABLE4);
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS "+TABLE5);
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS "+TABLE6);
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS "+TABLE7);
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS "+TABLE8);
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS "+TABLE9);
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS "+TABLE10);
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS "+TABLE11);
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS "+TABLE12);
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS "+TABLE13);
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS "+TABLE14);
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS "+TABLE15);
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS "+TABLE16);
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS "+TABLE17);
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS "+TABLE18);
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS "+TABLE19);
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS "+TABLE20);
        sqLiteDatabase.execSQL("DROP TABLE if EXISTS "+TABLE21);
        onCreate(sqLiteDatabase);

    }
    public boolean insertData1(String name, String date, String pid, String age, String wifeOf, String occ, String address, String mobile, String landline)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL1,name);
        contentValues.put(COL2,date);
        contentValues.put(COL3,pid);
        contentValues.put(COL4,age);
        contentValues.put(COL5,wifeOf);
        contentValues.put(COL6,occ);
        contentValues.put(COL7,address);
        contentValues.put(COL8,mobile);
        contentValues.put(COL9,landline);
        contentValues.put(COL179, "No");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        String format = simpleDateFormat.format(new Date());
        contentValues.put(COL181,format);
        long result=sqLiteDatabase.insert(TABLE1,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;

    }

    public boolean insertData0(String dname,String pid, String date)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL0,dname);
        contentValues.put(COL3,pid);
        contentValues.put(COL177,date);
        contentValues.put(COL179, "No");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        String format = simpleDateFormat.format(new Date());
        contentValues.put(COL181,format);
        long result=sqLiteDatabase.insert(TABLE0,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;

    }

    public boolean insertData2(String pid, String hoam, String hoad,String lmp, String edd, String gw, String cedd, String ac1)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL3,pid);
        contentValues.put(COL10,hoam);
        contentValues.put(COL11,hoad);
        contentValues.put(COL12,lmp);
        contentValues.put(COL13,edd);
        contentValues.put(COL14,gw);
        contentValues.put(COL15,cedd);
        contentValues.put(COL16,ac1);
        contentValues.put(COL179, "No");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        String format = simpleDateFormat.format(new Date());
        contentValues.put(COL181,format);
        long result=sqLiteDatabase.insert(TABLE2,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }

    public boolean insertData3(String pid,String h, String bm, String bpsp, String re, String fwr, String fai, String odi, String o1, String s1)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL3,pid);
        contentValues.put(COL17,h);
        contentValues.put(COL18,bm);
        contentValues.put(COL19,bpsp);
        contentValues.put(COL20,re);
        contentValues.put(COL21,fwr);
        contentValues.put(COL22,fai);
        contentValues.put(COL23,odi);
        contentValues.put(COL24,o1);
        contentValues.put(COL25,s1);
        contentValues.put(COL179, "No");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        String format = simpleDateFormat.format(new Date());
        contentValues.put(COL181,format);
        long result=sqLiteDatabase.insert(TABLE3,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }

    public boolean insertData4(String pid,String q, String hobp,String lp, String pih, String tt, String it, String ct, String o2, String s2)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL3,pid);
        contentValues.put(COL26,q);
        contentValues.put(COL27,hobp);
        contentValues.put(COL28,lp);
        contentValues.put(COL29,pih);
        contentValues.put(COL30,tt);
        contentValues.put(COL31,it);
        contentValues.put(COL32,ct);
        contentValues.put(COL33,o2);
        contentValues.put(COL34,s2);
        contentValues.put(COL179, "No");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        String format = simpleDateFormat.format(new Date());
        contentValues.put(COL181,format);
        long result=sqLiteDatabase.insert(TABLE4,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }

    public boolean insertData5(String pid, String pia, String lp,String bp, String fm, String pih, String it, String ct, String o3, String s3)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL3,pid);
        contentValues.put(COL35,pia);
        contentValues.put(COL36,lp);
        contentValues.put(COL37,bp);
        contentValues.put(COL38,fm);
        contentValues.put(COL39,pih);
        contentValues.put(COL40,it);
        contentValues.put(COL41,ct);
        contentValues.put(COL42,o3);
        contentValues.put(COL43,s3);
        contentValues.put(COL179, "No");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        String format = simpleDateFormat.format(new Date());
        contentValues.put(COL181,format);
        long result=sqLiteDatabase.insert(TABLE5,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }
    public boolean insertData6(String pid, String tno, String h,String bgrt, String a, String s, String m, String vdrl, String hiv, String hbsag, String rbs, String o4)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL3,pid);
        contentValues.put(COL178,tno);
        contentValues.put(COL44,h);
        contentValues.put(COL45,bgrt);
        contentValues.put(COL46,a);
        contentValues.put(COL47,s);
        contentValues.put(COL48,m);
        contentValues.put(COL49,vdrl);
        contentValues.put(COL50,hiv);
        contentValues.put(COL51,hbsag);
        contentValues.put(COL52,rbs);
        contentValues.put(COL53,o4);
        contentValues.put(COL179, "No");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        String format = simpleDateFormat.format(new Date());
        contentValues.put(COL181,format);
        long result=sqLiteDatabase.insert(TABLE6,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }

    public boolean insertData7(String pid, String g, String p, String a, String l, String d)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL3,pid);
        contentValues.put(COL54,g);
        contentValues.put(COL55,p);
        contentValues.put(COL56,a);
        contentValues.put(COL57,l);
        contentValues.put(COL58,d);
        contentValues.put(COL179,"No");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        String format = simpleDateFormat.format(new Date());
        contentValues.put(COL181,format);
        long result=sqLiteDatabase.insert(TABLE7,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }

    public boolean insertData8(String pid,String po, String tpt, String md, String ant, String intr, String pos, String ad, String gen, String bw, String pam, String pad )
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL3,pid);
        contentValues.put(COL59,po);
        contentValues.put(COL60,tpt);
        contentValues.put(COL61,md);
        contentValues.put(COL62,ant);
        contentValues.put(COL63,intr);
        contentValues.put(COL64,pos);
        contentValues.put(COL65,ad);
        contentValues.put(COL66,gen);
        contentValues.put(COL67,bw);
        contentValues.put(COL68,pam);
        contentValues.put(COL69,pad);
        contentValues.put(COL179,"No");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        String format = simpleDateFormat.format(new Date());
        contentValues.put(COL181,format);
        long result=sqLiteDatabase.insert(TABLE8,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }

    public boolean insertData9(String pid,String h1, String h2, String h3, String h4)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL3,pid);
        contentValues.put(COL70,h1);
        contentValues.put(COL71,h2);
        contentValues.put(COL72,h3);
        contentValues.put(COL73,h4);
        contentValues.put(COL179,"No");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        String format = simpleDateFormat.format(new Date());
        contentValues.put(COL181,format);
        long result=sqLiteDatabase.insert(TABLE9,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }

    public boolean insertData10(String pid,String di, String sl, String adh, String alk)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL3,pid);
        contentValues.put(COL74,di);
        contentValues.put(COL75,sl);
        contentValues.put(COL76,adh);
        contentValues.put(COL77,alk);
        contentValues.put(COL179,"No");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        String format = simpleDateFormat.format(new Date());
        contentValues.put(COL181,format);
        long result=sqLiteDatabase.insert(TABLE10,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }

    public boolean insertData11(String pid,String h, String w, String bmi, String pr, String bp, String temp, String br, String nip, String thy, String spi, String ict, String pal, String ede, String cya, String clu, String lym)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL3,pid);
        contentValues.put(COL78,h);
        contentValues.put(COL79,w);
        contentValues.put(COL80,bmi);
        contentValues.put(COL81,pr);
        contentValues.put(COL82,bp);
        contentValues.put(COL83,temp);
        contentValues.put(COL84,br);
        contentValues.put(COL85,nip);
        contentValues.put(COL86,thy);
        contentValues.put(COL87,spi);
        contentValues.put(COL88,ict);
        contentValues.put(COL89,pal);
        contentValues.put(COL90,ede);
        contentValues.put(COL91,cya);
        contentValues.put(COL92,clu);
        contentValues.put(COL93,lym);
        contentValues.put(COL179,"No");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        String format = simpleDateFormat.format(new Date());
        contentValues.put(COL181,format);
        long result=sqLiteDatabase.insert(TABLE11,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }

    public boolean insertData12(String pid, String cvs, String rs, String cns, String us, String pres,String fhs, String liq, String ps)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL3,pid);
        contentValues.put(COL94,cvs);
        contentValues.put(COL95,rs);
        contentValues.put(COL96,cns);
        contentValues.put(COL97,us);
        contentValues.put(COL98,pres);
        contentValues.put(COL99,fhs);
        contentValues.put(COL100,liq);
        contentValues.put(COL101,ps);
        contentValues.put(COL179,"No");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        String format = simpleDateFormat.format(new Date());
        contentValues.put(COL181,format);
        long result=sqLiteDatabase.insert(TABLE12,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }

    public boolean insertData13(String pid, String cc, String lmp, String hopl, String mh)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL3,pid);
        contentValues.put(COL102,cc);
        contentValues.put(COL103,lmp);
        contentValues.put(COL104,hopl);
        contentValues.put(COL105,mh);
        contentValues.put(COL179,"No");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        String format = simpleDateFormat.format(new Date());
        contentValues.put(COL181,format);
        long result=sqLiteDatabase.insert(TABLE13,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }

    public boolean insertData14(String pid, String ml, String p, String a, String l)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL3,pid);
        contentValues.put(COL106,ml);
        contentValues.put(COL107,p);
        contentValues.put(COL108,a);
        contentValues.put(COL109,l);
        contentValues.put(COL179,"No");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        String format = simpleDateFormat.format(new Date());
        contentValues.put(COL181,format);
        long result=sqLiteDatabase.insert(TABLE14,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }

    public boolean insertData15(String pid, String d, String h,String t, String ep, String cd, String rd, String vd,String bt, String lp, String o)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL3,pid);
        contentValues.put(COL110,d);
        contentValues.put(COL111,h);
        contentValues.put(COL112,t);
        contentValues.put(COL113,ep);
        contentValues.put(COL114,cd);
        contentValues.put(COL115,rd);
        contentValues.put(COL116,vd);
        contentValues.put(COL117,bt);
        contentValues.put(COL118,lp);
        contentValues.put(COL119,o);
        contentValues.put(COL179,"No");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        String format = simpleDateFormat.format(new Date());
        contentValues.put(COL181,format);
        long result=sqLiteDatabase.insert(TABLE15,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }

    public boolean insertData16(String pid,String d, String ht,String tb, String mg,String o )
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL3,pid);
        contentValues.put(COL120,d);
        contentValues.put(COL121,ht);
        contentValues.put(COL122,tb);
        contentValues.put(COL123,mg);
        contentValues.put(COL124,o);
        contentValues.put(COL179,"No");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        String format = simpleDateFormat.format(new Date());
        contentValues.put(COL181,format);
        long result=sqLiteDatabase.insert(TABLE16,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }

    public boolean insertData17(String pid,String diet, String app, String sle, String mic, String bwl, String hbts, String ah)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL3,pid);
        contentValues.put(COL125,diet);
        contentValues.put(COL126,app);
        contentValues.put(COL127,sle);
        contentValues.put(COL128,mic);
        contentValues.put(COL129,bwl);
        contentValues.put(COL130,hbts);
        contentValues.put(COL131,ah);
        contentValues.put(COL179,"No");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        String format = simpleDateFormat.format(new Date());
        contentValues.put(COL181,format);
        long result=sqLiteDatabase.insert(TABLE17,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }

    public boolean insertData18(String pid, String ht, String wt, String bmi, String temp, String pulse,String bp, String thy, String bre, String spi, String pal, String ic,String cy, String clu, String lym, String ede)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL3,pid);
        contentValues.put(COL132,ht);
        contentValues.put(COL133,wt);
        contentValues.put(COL134,bmi);
        contentValues.put(COL135,temp);
        contentValues.put(COL136,pulse);
        contentValues.put(COL137,bp);
        contentValues.put(COL138,thy);
        contentValues.put(COL139,bre);
        contentValues.put(COL140,spi);
        contentValues.put(COL141,pal);
        contentValues.put(COL142,ic);
        contentValues.put(COL143,cy);
        contentValues.put(COL144,clu);
        contentValues.put(COL145,lym);
        contentValues.put(COL146,ede);
        contentValues.put(COL179,"No");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        String format = simpleDateFormat.format(new Date());
        contentValues.put(COL181,format);
        long result=sqLiteDatabase.insert(TABLE18,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }

    public boolean insertData19(String pid, String cvs, String rs, String cns, String ins, String pal, String per,String aus, String le, String se, String be, String re, String pd)
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL3,pid);
        contentValues.put(COL147,cvs);
        contentValues.put(COL148,rs);
        contentValues.put(COL149,cns);
        contentValues.put(COL150,ins);
        contentValues.put(COL151,pal);
        contentValues.put(COL152,per);
        contentValues.put(COL153,aus);
        contentValues.put(COL154,le);
        contentValues.put(COL155,se);
        contentValues.put(COL156,be);
        contentValues.put(COL157,re);
        contentValues.put(COL158,pd);
        contentValues.put(COL179,"No");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        String format = simpleDateFormat.format(new Date());
        contentValues.put(COL181,format);
        long result=sqLiteDatabase.insert(TABLE19,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }

    public boolean insertData20(String pid,String hb, String tc, String pc, String phs, String bgrt, String al, String su, String mi, String cs, String hiv, String hbsag,String vdrl, String rbs, String fbs, String ppbs, String ult, String ps )
    {
        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL3,pid);
        contentValues.put(COL159,hb);
        contentValues.put(COL160,tc);
        contentValues.put(COL161,pc);
        contentValues.put(COL162,phs);
        contentValues.put(COL163,bgrt);
        contentValues.put(COL164,al);
        contentValues.put(COL165,su);
        contentValues.put(COL166,mi);
        contentValues.put(COL167,cs);
        contentValues.put(COL168,hiv);
        contentValues.put(COL169,hbsag);
        contentValues.put(COL170,vdrl);
        contentValues.put(COL171,rbs);
        contentValues.put(COL172,fbs);
        contentValues.put(COL173,ppbs);
        contentValues.put(COL174,ult);
        contentValues.put(COL175,ps);
        contentValues.put(COL179,"No");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        String format = simpleDateFormat.format(new Date());
        contentValues.put(COL181,format);
        long result=sqLiteDatabase.insert(TABLE20,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }

    public boolean insertData21(String pid, String poc,String adv )
    {

        SQLiteDatabase sqLiteDatabase=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL3,pid);
        contentValues.put(COL176,poc);
        contentValues.put(COL180,adv);
        contentValues.put(COL179,"No");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        String format = simpleDateFormat.format(new Date());
        contentValues.put(COL181,format);
        long result=sqLiteDatabase.insert(TABLE20,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }



}


