package com.example.mathanky.gynocare;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.ContentFrameLayout;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class form1 extends AppCompatActivity {

    private static EditText e1,e2,e3,e4,e5,e6,e7,e8,e9;
    private static Button b1;
    DBHelper myDb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.form1);
        myDb=new DBHelper(this);
        e1=(EditText)findViewById(R.id.name_box);
        e2=(EditText)findViewById(R.id.date_box);
        e3=(EditText)findViewById(R.id.reg_box);
        e4=(EditText)findViewById(R.id.age_box);
        e5=(EditText)findViewById(R.id.wife_box);
        e6=(EditText)findViewById(R.id.occupation);
        e7=(EditText)findViewById(R.id.address_box);
        e8=(EditText)findViewById(R.id.mobile_box);
        e9=(EditText)findViewById(R.id.landline_box);
        b1=(Button)findViewById(R.id.proceed1);
        onBtnProceed1();
    }

    public void onButton()
    {
       b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ValidationSuccess()){
                    onBtnProceed1();
                }
            }
        });
    }

    private boolean ValidationSuccess(){

        if (e1.getText().toString().equalsIgnoreCase("")){
            e1.setError("Please enter name");
            return false;
        }

        if (e7.getText().toString().equalsIgnoreCase("")){
            e7.setError("Please enter address");
            return false;
        }

        if (e3.getText().toString().equalsIgnoreCase("")){
            e3.setError("Please enter registration number");
            return false;
        }

        if (e4.getText().toString().equalsIgnoreCase("")){
            e4.setError("Please enter age");
            return false;
        }

        if (Integer.parseInt(e4.getText().toString())>200){
            e4.setError("Exceeds limit! Please enter a valid age");
            return false;
        }

        if (e5.getText().toString().equalsIgnoreCase("")){
            e5.setError("Please enter name");
            return false;
        }

        if (e8.getText().toString().equalsIgnoreCase("")){
            e8.setError("Please enter mobile number");
            return false;
        }

        if (e8.getText().toString().length()!=10){
            e8.setError("Please enter a valid 10 digit mobile number");
            return false;
        }

        return true;
    }

    protected void onBtnProceed1()
    {

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String d1=getIntent().getExtras().getString("doc_name");
                String d2=getIntent().getExtras().getString("doe");
                boolean isInserted0=myDb.insertData0(d1, e3.getText().toString(),d2);
                boolean isInserted1=myDb.insertData1(e1.getText().toString(),e2.getText().toString(),e3.getText().toString(),e4.getText().toString(),e5.getText().toString(),e6.getText().toString(),e7.getText().toString(),e8.getText().toString(),e9.getText().toString());
                if(isInserted0 && isInserted1)
                {
                    Toast.makeText(form1.this,"Saved", Toast.LENGTH_LONG).show();
                }
                else
                    Toast.makeText(form1.this,"Not Saved",Toast.LENGTH_LONG).show();
                Intent intent = new Intent("com.example.mathanky.gynocare.form2");
                intent.putExtra("pid",e3.getText().toString());
                startActivity(intent);
            }
        });
    }


}
