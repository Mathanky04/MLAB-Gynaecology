package com.example.mathanky.gynocare;


/**
 * Created by Shruthi on 7/25/2016.
 */

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class form7 extends AppCompatActivity {

    private static TextView btnNext2;
    EditText e1,e2,e3,e4,e5,e6, e7, e8, e9;
    RadioGroup rg1, rg2, rg3, rg4, rg5,rg6,rg7,rg8, rg9, rg10, rg11, rg12;
    RadioButton selectedRadioButton, sr2, sr3, sr4, sr5, sr6, sr7, sr8, sr9, sr10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.form7);

        e1 = (EditText)findViewById(R.id.breasts_box) ;
        e2 = (EditText)findViewById(R.id.nipples_box) ;
        e3 = (EditText)findViewById(R.id.thyroid_box) ;
        e4 = (EditText)findViewById(R.id.spine_box) ;
        e5 = (EditText)findViewById(R.id.icterus_box) ;
        rg11 = (RadioGroup)findViewById(R.id.pallor_positive);
        e6 = (EditText)findViewById(R.id.edema_box) ;
        e7 = (EditText)findViewById(R.id.cyanosis_box) ;
        e8 = (EditText)findViewById(R.id.clubbing_box) ;
        e9 = (EditText)findViewById(R.id.lymphadenopathy_box) ;

        e1.setVisibility(View.GONE);
        e2.setVisibility(View.GONE);
        e3.setVisibility(View.GONE);
        e4.setVisibility(View.GONE);
        e5.setVisibility(View.GONE);
        e6.setVisibility(View.GONE);
        e7.setVisibility(View.GONE);
        e8.setVisibility(View.GONE);
        e9.setVisibility(View.GONE);
        rg11.setVisibility(View.GONE);


        btnNext2=(TextView)findViewById(R.id.next_page7);
        onButton();
    }

    public void onButton()
    {
        btnNext2=(TextView) findViewById(R.id.next_page7);
        btnNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ValidationSuccess()){
                    onBtnNext2();
                }
            }
        });
    }

    private boolean ValidationSuccess(){

        boolean check=true;
        StringBuilder errMsg = new StringBuilder("");


        rg2 = (RadioGroup)findViewById(R.id.nipples);
        sr2 = (RadioButton)findViewById(R.id.nipples_retracted);
        rg3 = (RadioGroup)findViewById(R.id.thyroid);
        sr3 = (RadioButton)findViewById(R.id.thyroid_abnormal);
        rg4 = (RadioGroup)findViewById(R.id.spine);
        sr4 = (RadioButton)findViewById(R.id.spine_abnormal);
        rg5 = (RadioGroup)findViewById(R.id.icterus);
        sr5 = (RadioButton)findViewById(R.id.icterus_present);
        rg6 = (RadioGroup)findViewById(R.id.pallor);
        sr6 = (RadioButton)findViewById(R.id.pallor_present);
        rg7 = (RadioGroup)findViewById(R.id.edema);
        sr7 = (RadioButton)findViewById(R.id.edema_present);
        rg8 = (RadioGroup)findViewById(R.id.cyanosis);
        sr8 = (RadioButton)findViewById(R.id.cyanosis_present);
        rg9 = (RadioGroup)findViewById(R.id.clubbing);
        sr9 = (RadioButton)findViewById(R.id.clubbing_present);
        rg10 = (RadioGroup)findViewById(R.id.lymphadenopathy);
        sr10 = (RadioButton)findViewById(R.id.lymphadenopathy_present);
        rg12 = (RadioGroup)findViewById(R.id.temp);


        rg1=(RadioGroup)findViewById(R.id.breasts);
        selectedRadioButton = (RadioButton)findViewById(R.id.breasts_abnormal);

        e1 = (EditText)findViewById(R.id.height) ;
        if (e1.getText().toString().equalsIgnoreCase("")){
            e1.setError("Please enter a value");
            check=false;
        }

        e1 = (EditText)findViewById(R.id.weight) ;
        if (e1.getText().toString().equalsIgnoreCase("")){
            e1.setError("Please enter a value");
            check=false;
        }

        e1 = (EditText)findViewById(R.id.pr) ;
        if (e1.getText().toString().equalsIgnoreCase("")){
            e1.setError("Please enter a value");
            check=false;
        }

        e1 = (EditText)findViewById(R.id.bp) ;
        if (e1.getText().toString().equalsIgnoreCase("")){
            e1.setError("Please enter a value");
            check=false;
        }

        if (rg1.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg12.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg2.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg3.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg4.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg5.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg6.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg7.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg8.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg9.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg10.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if(selectedRadioButton.isChecked())
        {
            e1 = (EditText)findViewById(R.id.breasts_box) ;
            if (e1.getText().toString().equalsIgnoreCase("")){
                e1.setError("Please enter a value");
                check=false;
            }
        }

        if(sr2.isChecked())
        {
            e2 = (EditText)findViewById(R.id.nipples_box) ;
            if (e2.getText().toString().equalsIgnoreCase("")){
                e2.setError("Please enter a value");
                check=false;
            }
        }

        if(sr3.isChecked())
        {
            e3 = (EditText)findViewById(R.id.thyroid_box) ;
            if (e3.getText().toString().equalsIgnoreCase("")){
                e3.setError("Please enter a value");
                check=false;
            }
        }

        if(sr4.isChecked())
        {
            e4 = (EditText)findViewById(R.id.spine_box) ;
            if (e4.getText().toString().equalsIgnoreCase("")){
                e4.setError("Please enter a value");
                check=false;
            }
        }

        if(sr5.isChecked())
        {
            e5 = (EditText)findViewById(R.id.icterus_box) ;
            if (e5.getText().toString().equalsIgnoreCase("")){
                e5.setError("Please enter a value");
                check=false;
            }
        }

        if(sr6.isChecked())
        {
            rg11 = (RadioGroup)findViewById(R.id.pallor_positive);
            if (rg11.getCheckedRadioButtonId() == -1)
            {
                errMsg.append("Please select on option\n");
                check=false;
            }
        }

        if(sr7.isChecked())
        {
            e5 = (EditText)findViewById(R.id.edema_box) ;
            if (e5.getText().toString().equalsIgnoreCase("")){
                e5.setError("Please enter a value");
                check=false;
            }
        }

        if(sr8.isChecked())
        {
            e5 = (EditText)findViewById(R.id.cyanosis_box) ;
            if (e5.getText().toString().equalsIgnoreCase("")){
                e5.setError("Please enter a value");
                check=false;
            }
        }

        if(sr9.isChecked())
        {
            e5 = (EditText)findViewById(R.id.clubbing_box) ;
            if (e5.getText().toString().equalsIgnoreCase("")){
                e5.setError("Please enter a value");
                check=false;
            }
        }

        if(sr10.isChecked())
        {
            e5 = (EditText)findViewById(R.id.lymphadenopathy_box) ;
            if (e5.getText().toString().equalsIgnoreCase("")){
                e5.setError("Please enter a value");
                check=false;
            }
        }




        return check;
    }

    public void onBtnNext2()
    {

        btnNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent("com.example.mathanky.gynocare.form8");
                startActivity(intent);
            }
        });
    }

    public void click(View view)
    {
        e1 = (EditText)findViewById(R.id.breasts_box) ;
        e1.setVisibility(View.VISIBLE);
    }

    public void click1(View view)
    {
        e1 = (EditText)findViewById(R.id.breasts_box) ;
        e1.setVisibility(View.GONE);
    }

    public void click2(View view)
    {
        e2 = (EditText)findViewById(R.id.nipples_box) ;
        e2.setVisibility(View.VISIBLE);
    }

    public void click3(View view)
    {
        e2 = (EditText)findViewById(R.id.nipples_box) ;
        e2.setVisibility(View.GONE);
    }

    public void click4(View view)
    {
        e3 = (EditText)findViewById(R.id.thyroid_box) ;
        e3.setVisibility(View.VISIBLE);
    }

    public void click5(View view)
    {
        e3 = (EditText)findViewById(R.id.thyroid_box) ;
        e3.setVisibility(View.GONE);
    }

    public void click18(View view)
    {
        e3 = (EditText)findViewById(R.id.spine_box) ;
        e3.setVisibility(View.VISIBLE);
    }

    public void click19(View view)
    {
        e3 = (EditText)findViewById(R.id.spine_box) ;
        e3.setVisibility(View.GONE);
    }

    public void click6(View view)
    {
        e4 = (EditText)findViewById(R.id.icterus_box) ;
        e4.setVisibility(View.VISIBLE);
    }

    public void click7(View view)
    {
        e4 = (EditText)findViewById(R.id.icterus_box) ;
        e4.setVisibility(View.GONE);
    }

    public void click8(View view)
    {
        rg11 = (RadioGroup)findViewById(R.id.pallor_positive);
        rg11.setVisibility(View.VISIBLE);
    }

    public void click9(View view)
    {
        rg11 = (RadioGroup)findViewById(R.id.pallor_positive);
        rg11.setVisibility(View.GONE);
    }

    public void click10(View view)
    {
        e6 = (EditText)findViewById(R.id.edema_box) ;
        e6.setVisibility(View.VISIBLE);
    }

    public void click11(View view)
    {
        e6 = (EditText)findViewById(R.id.edema_box) ;
        e6.setVisibility(View.GONE);
    }

    public void click12(View view)
    {
        e6 = (EditText)findViewById(R.id.cyanosis_box) ;
        e6.setVisibility(View.VISIBLE);
    }

    public void click13(View view)
    {
        e6 = (EditText)findViewById(R.id.cyanosis_box) ;
        e6.setVisibility(View.GONE);
    }

    public void click14(View view)
    {
        e6 = (EditText)findViewById(R.id.clubbing_box) ;
        e6.setVisibility(View.VISIBLE);
    }

    public void click15(View view)
    {
        e6 = (EditText)findViewById(R.id.clubbing_box) ;
        e6.setVisibility(View.GONE);
    }

    public void click16(View view)
    {
        e6 = (EditText)findViewById(R.id.lymphadenopathy_box) ;
        e6.setVisibility(View.VISIBLE);
    }

    public void click17(View view)
    {
        e6 = (EditText)findViewById(R.id.lymphadenopathy_box) ;
        e6.setVisibility(View.GONE);
    }




}
