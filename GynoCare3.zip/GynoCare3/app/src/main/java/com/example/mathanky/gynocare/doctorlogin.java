package com.example.mathanky.gynocare;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

/**
 * Created by usha on 8/16/2016.
 */
public class doctorlogin extends AppCompatActivity {
    Button btn;
    EditText e1,e2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.doctorlogin);
        e1=(EditText)findViewById(R.id.doctor_name_box);
        e2=(EditText)findViewById(R.id.doctor_date_box);
        btn=(Button)findViewById(R.id.button3);
        onbtn();
    }

    public void onbtn()
    {
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent("com.example.mathanky.gynocare.choice");
                intent.putExtra("doc_name",e1.getText().toString());
                intent.putExtra("doe",e2.getText().toString());
                startActivity(intent);
            }
        });
    }
}
