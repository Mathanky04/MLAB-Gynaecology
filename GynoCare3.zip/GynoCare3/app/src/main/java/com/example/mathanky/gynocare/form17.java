package com.example.mathanky.gynocare;


/**
 * Created by Shruthi on 7/25/2016.
 */

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class form17 extends AppCompatActivity {

    private static TextView btnNext2;
    EditText e1,e2,e3,e4,e5,e6,e7, e8, e9;
    RadioGroup rg1, rg2, rg3, rg4, rg5, rg6, rg7, rg8, rg9, rg10, rg11, rg12, rg13;
    RadioButton selectedRadioButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.form17);

        btnNext2=(TextView)findViewById(R.id.next_page17);
        onButton();
    }

    public void onButton()
    {
        btnNext2=(TextView) findViewById(R.id.next_page17);
        btnNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ValidationSuccess()){
                    onBtnNext2();
                }
            }
        });
    }

    private boolean ValidationSuccess(){

        boolean check=true;
        StringBuilder errMsg = new StringBuilder("");


        rg2 = (RadioGroup)findViewById(R.id.sleep);
        rg3 = (RadioGroup)findViewById(R.id.allergy);

        e1 = (EditText)findViewById(R.id.Hb_inv_box);
        e2 = (EditText)findViewById(R.id.HbsAg);
        e3 = (EditText)findViewById(R.id.VDRL);
        e4 = (EditText)findViewById(R.id.RBS);


        rg1=(RadioGroup)findViewById(R.id.TC);
        rg2=(RadioGroup)findViewById(R.id.platelet_count);
        rg3=(RadioGroup)findViewById(R.id.Peripheral_Smear);
        rg4=(RadioGroup)findViewById(R.id.blood_grouping);
        rg5=(RadioGroup)findViewById(R.id.albumin);
        rg6=(RadioGroup)findViewById(R.id.Sugar);
        rg7=(RadioGroup)findViewById(R.id.Microscopy);
        rg8=(RadioGroup)findViewById(R.id.CS);
        rg9=(RadioGroup)findViewById(R.id.HIV);
        rg10=(RadioGroup)findViewById(R.id.FBS);
        rg11=(RadioGroup)findViewById(R.id.PPBS);
        rg12=(RadioGroup)findViewById(R.id.Ultrasound);
        rg13=(RadioGroup)findViewById(R.id.Pap_Smear);


        if (e1.getText().toString().equalsIgnoreCase("")){
            e1.setError("Please enter a value");
            check=false;
        }

        if (e2.getText().toString().equalsIgnoreCase("")){
            e2.setError("Please enter a value");
            check=false;
        }

        if (e3.getText().toString().equalsIgnoreCase("")){
            e3.setError("Please enter a value");
            check=false;
        }

        if (e4.getText().toString().equalsIgnoreCase("")){
            e4.setError("Please enter a value");
            check=false;
        }

        if (rg1.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg2.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg3.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg4.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg5.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg6.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }if (rg7.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg8.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg9.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }
        if (rg10.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg11.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg12.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }
        if (rg13.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }


        return check;
    }

    public void onBtnNext2()
    {

        btnNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent("com.example.mathanky.gynocare.form18");
                startActivity(intent);
            }
        });
    }



}
