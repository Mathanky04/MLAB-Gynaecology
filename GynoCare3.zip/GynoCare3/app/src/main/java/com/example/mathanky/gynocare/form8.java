package com.example.mathanky.gynocare;


/**
 * Created by Shruthi on 7/25/2016.
 */

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class form8 extends AppCompatActivity {

    private static TextView btnNext2;
    EditText e1,e2,e3,e4,e5,e6, e7, e8, e9;
    RadioGroup rg1, rg2, rg3, rg4, rg5,rg6,rg7,rg8, rg9, rg10, rg11, rg12;
    RadioButton selectedRadioButton, sr2, sr3, sr4, sr5, sr6, sr7, sr8, sr9, sr10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.form8);

        e1 = (EditText)findViewById(R.id.cvs_box) ;
        e2 = (EditText)findViewById(R.id.rs_box) ;
        e3 = (EditText)findViewById(R.id.cns_box) ;
        e4 = (EditText)findViewById(R.id.previous_scar_box) ;
        rg11 = (RadioGroup)findViewById(R.id.fhs_positive);

        e1.setVisibility(View.GONE);
        e2.setVisibility(View.GONE);
        e3.setVisibility(View.GONE);
        e4.setVisibility(View.GONE);
        rg11.setVisibility(View.GONE);


        btnNext2=(TextView)findViewById(R.id.next_page8);
        onButton();
    }

    public void onButton()
    {
        btnNext2=(TextView) findViewById(R.id.next_page8);
        btnNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ValidationSuccess()){
                    onBtnNext2();
                }
            }
        });
    }

    private boolean ValidationSuccess(){

        boolean check=true;
        StringBuilder errMsg = new StringBuilder("");


        rg2 = (RadioGroup)findViewById(R.id.rs);
        sr2 = (RadioButton)findViewById(R.id.rs_abnormal);
        rg3 = (RadioGroup)findViewById(R.id.cns);
        sr3 = (RadioButton)findViewById(R.id.cns_abnormal);
        rg4 = (RadioGroup)findViewById(R.id.presentation);

        rg5 = (RadioGroup)findViewById(R.id.fhs);
        sr5 = (RadioButton)findViewById(R.id.fhs_plus);
        rg6 = (RadioGroup)findViewById(R.id.liquor);

        rg7 = (RadioGroup)findViewById(R.id.previous_scar);
        sr7 = (RadioButton)findViewById(R.id.previous_scar_present);

        rg1=(RadioGroup)findViewById(R.id.cvs);
        selectedRadioButton = (RadioButton)findViewById(R.id.cvs_abnormal);

        e1 = (EditText)findViewById(R.id.uterine_size) ;
        if (e1.getText().toString().equalsIgnoreCase("")){
            e1.setError("Please enter a value");
            check=false;
        }

        if (rg1.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg2.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg3.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg4.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg5.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg6.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg7.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }


        if(selectedRadioButton.isChecked())
        {
            e1 = (EditText)findViewById(R.id.cvs_box) ;
            if (e1.getText().toString().equalsIgnoreCase("")){
                e1.setError("Please enter a value");
                check=false;
            }
        }

        if(sr2.isChecked())
        {
            e2 = (EditText)findViewById(R.id.rs_box) ;
            if (e2.getText().toString().equalsIgnoreCase("")){
                e2.setError("Please enter a value");
                check=false;
            }
        }

        if(sr3.isChecked())
        {
            e3 = (EditText)findViewById(R.id.cns_box) ;
            if (e3.getText().toString().equalsIgnoreCase("")){
                e3.setError("Please enter a value");
                check=false;
            }
        }


        if(sr5.isChecked())
        {
            rg11 = (RadioGroup)findViewById(R.id.fhs_positive);
            if (rg11.getCheckedRadioButtonId() == -1)
            {
                errMsg.append("Please select on option\n");
                check=false;
            }
        }


        if(sr7.isChecked())
        {
            e5 = (EditText)findViewById(R.id.previous_scar_box) ;
            if (e5.getText().toString().equalsIgnoreCase("")){
                e5.setError("Please enter a value");
                check=false;
            }
        }

        if(sr8.isChecked())
        {
            e5 = (EditText)findViewById(R.id.cyanosis_box) ;
            if (e5.getText().toString().equalsIgnoreCase("")){
                e5.setError("Please enter a value");
                check=false;
            }
        }

        if(sr9.isChecked())
        {
            e5 = (EditText)findViewById(R.id.clubbing_box) ;
            if (e5.getText().toString().equalsIgnoreCase("")){
                e5.setError("Please enter a value");
                check=false;
            }
        }

        if(sr10.isChecked())
        {
            e5 = (EditText)findViewById(R.id.lymphadenopathy_box) ;
            if (e5.getText().toString().equalsIgnoreCase("")){
                e5.setError("Please enter a value");
                check=false;
            }
        }




        return check;
    }

    public void onBtnNext2()
    {

        btnNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                 Intent intent = new Intent("com.example.mathanky.gynocare.form10");
                 startActivity(intent);
            }
        });
    }

    public void click(View view)
    {
        e1 = (EditText)findViewById(R.id.cvs_box) ;
        e1.setVisibility(View.VISIBLE);
    }

    public void click1(View view)
    {
        e1 = (EditText)findViewById(R.id.cvs_box) ;
        e1.setVisibility(View.GONE);
    }

    public void click2(View view)
    {
        e2 = (EditText)findViewById(R.id.rs_box) ;
        e2.setVisibility(View.VISIBLE);
    }

    public void click3(View view)
    {
        e2 = (EditText)findViewById(R.id.rs_box) ;
        e2.setVisibility(View.GONE);
    }

    public void click4(View view)
    {
        e3 = (EditText)findViewById(R.id.cns_box) ;
        e3.setVisibility(View.VISIBLE);
    }

    public void click5(View view)
    {
        e3 = (EditText)findViewById(R.id.cns_box) ;
        e3.setVisibility(View.GONE);
    }

    public void click8(View view)
    {
        e3 = (EditText)findViewById(R.id.previous_scar_box) ;
        e3.setVisibility(View.VISIBLE);
    }

    public void click9(View view)
    {
        e3 = (EditText)findViewById(R.id.previous_scar_box) ;
        e3.setVisibility(View.GONE);
    }

    public void click6(View view)
    {
        rg11 = (RadioGroup)findViewById(R.id.fhs_positive);
        rg11.setVisibility(View.VISIBLE);
    }

    public void click7(View view)
    {
        rg11 = (RadioGroup)findViewById(R.id.fhs_positive);
        rg11.setVisibility(View.GONE);
    }


}
