package com.example.mathanky.gynocare;


/**
 * Created by Shruthi on 7/25/2016.
 */

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class form18 extends AppCompatActivity {

    private static TextView btnNext2;
    EditText e1,e2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.form18);

        btnNext2=(TextView)findViewById(R.id.submit);
        onButton();
    }

    public void onButton()
    {
        btnNext2=(TextView) findViewById(R.id.submit);
        btnNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ValidationSuccess()){
                    onBtnNext2();
                }
            }
        });
    }

    private boolean ValidationSuccess(){

        boolean check=true;
        StringBuilder errMsg = new StringBuilder("");

        e1 = (EditText)findViewById(R.id.plan) ;
        if (e1.getText().toString().equalsIgnoreCase("")){
            e1.setError("Please enter a value");
            check=false;
        }
        e2 = (EditText)findViewById(R.id.advice) ;
        if (e2.getText().toString().equalsIgnoreCase("")){
            e2.setError("Please enter a value");
            check=false;
        }

        return check;
    }

    public void onBtnNext2()
    {

        btnNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent("com.example.mathanky.gynocare.thankyou");
                startActivity(intent);
            }
        });
    }


}
