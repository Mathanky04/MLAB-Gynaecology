package com.example.mathanky.gynocare;


/**
 * Created by usha on 7/25/2016.
 */

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class form3second extends AppCompatActivity {

    private static TextView btnNext2;
    EditText e1,e2;
    EditText second_other_box, second_hb, rbs;
    RadioGroup rg1, rg2, rg3, rg4, rg5, rg6, rg7, rg8;
    RadioButton selectedRadioButton;
    CheckBox quickening, bleeding_piv, leak_piv, pih, tt, iron, second_other;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.form3second);

        quickening = (CheckBox) findViewById(R.id.quickening);
        bleeding_piv = (CheckBox) findViewById(R.id.bleeding_piv);
        leak_piv = (CheckBox) findViewById(R.id.leak_piv);
        pih = (CheckBox) findViewById(R.id.pih);
        tt = (CheckBox) findViewById(R.id.tt);
        iron = (CheckBox) findViewById(R.id.iron);

        second_other = (CheckBox) findViewById(R.id.second_other);
        second_other_box = (EditText)findViewById(R.id.second_other_box);

        second_other_box.setVisibility(View.GONE);

        quickening.setVisibility(View.GONE);
        bleeding_piv.setVisibility(View.GONE);
        leak_piv.setVisibility(View.GONE);
        pih.setVisibility(View.GONE);
        tt.setVisibility(View.GONE);
        iron.setVisibility(View.GONE);
        second_other.setVisibility(View.GONE);


        btnNext2=(TextView)findViewById(R.id.next_page3);
        onButton();
    }

    public void onButton()
    {
        btnNext2=(TextView) findViewById(R.id.next_page3);
        btnNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ValidationSuccess()){
                    onBtnNext2();
                }
            }
        });
    }

    private boolean ValidationSuccess(){

        boolean check=true;
        StringBuilder errMsg = new StringBuilder("");

        second_hb = (EditText)findViewById(R.id.second_hb) ;
        rg2 = (RadioGroup)findViewById(R.id.second_albumin);
        rg3 = (RadioGroup)findViewById(R.id.second_sugar);
        rg4 = (RadioGroup)findViewById(R.id.second_microscopy);
        rg5 = (RadioGroup)findViewById(R.id.second_vdrl);
        rg6 = (RadioGroup)findViewById(R.id.second_hiv);
        rg7 = (RadioGroup)findViewById(R.id.second_hbsag);
        rg8 =  (RadioGroup)findViewById(R.id.second_blood_group);
        rbs = (EditText)findViewById(R.id.second_rbs);

        rg1=(RadioGroup)findViewById(R.id.second_trimester_complaints);
        selectedRadioButton = (RadioButton)findViewById(R.id.second_trimester_complaints_yes);


        if (second_hb.getText().toString().equalsIgnoreCase("")){
            second_hb.setError("Please enter a value");
            check=false;
        }

        if (rbs.getText().toString().equalsIgnoreCase("")){
            second_hb.setError("Please enter a value");
            check=false;
        }

        if (rg1.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg2.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg3.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg4.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg5.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg6.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg7.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg8.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }


        if(selectedRadioButton.isChecked())
        {
            quickening = (CheckBox) findViewById(R.id.quickening);
            bleeding_piv = (CheckBox) findViewById(R.id.bleeding_piv);
            leak_piv = (CheckBox) findViewById(R.id.leak_piv);
            pih = (CheckBox) findViewById(R.id.pih);
            tt = (CheckBox) findViewById(R.id.tt);
            iron = (CheckBox) findViewById(R.id.iron);

            second_other = (CheckBox) findViewById(R.id.second_other);
            second_other_box = (EditText)findViewById(R.id.second_other_box);

            if (!(quickening.isChecked() || bleeding_piv.isChecked() || leak_piv.isChecked() || pih.isChecked() || tt.isChecked() || iron.isChecked() || second_other.isChecked())){
                quickening.setError("Please select an option");
                check=false;
            }


            else if(second_other.isChecked()&& second_other_box.getText().toString().equalsIgnoreCase("")){
                second_other.setError("Please enter a value");
                check=false;
            }

        }


        return check;
    }

    public void onBtnNext2()
    {

        btnNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent("com.example.mathanky.gynocare.form3third");
                startActivity(intent);
            }
        });
    }

    public void click(View view)
    {
        quickening = (CheckBox) findViewById(R.id.quickening);
        bleeding_piv = (CheckBox) findViewById(R.id.bleeding_piv);
        leak_piv = (CheckBox) findViewById(R.id.leak_piv);
        pih = (CheckBox) findViewById(R.id.pih);
        tt = (CheckBox) findViewById(R.id.tt);
        iron = (CheckBox) findViewById(R.id.iron);
        second_other = (CheckBox) findViewById(R.id.second_other);
        quickening.setVisibility(View.VISIBLE);
        bleeding_piv.setVisibility(View.VISIBLE);
        leak_piv.setVisibility(View.VISIBLE);
        pih.setVisibility(View.VISIBLE);
        tt.setVisibility(View.VISIBLE);
        iron.setVisibility(View.VISIBLE);
        second_other.setVisibility(View.VISIBLE);

    }


    public void click3(View view)
    {
        second_other_box = (EditText)findViewById(R.id.second_other_box);
        second_other_box.setVisibility(View.VISIBLE);

    }
    public void click1(View view)
    {
        quickening = (CheckBox) findViewById(R.id.quickening);
        bleeding_piv = (CheckBox) findViewById(R.id.bleeding_piv);
        leak_piv = (CheckBox) findViewById(R.id.leak_piv);
        pih = (CheckBox) findViewById(R.id.pih);
        tt = (CheckBox) findViewById(R.id.tt);
        iron = (CheckBox) findViewById(R.id.iron);

        second_other = (CheckBox) findViewById(R.id.second_other);
        second_other_box = (EditText)findViewById(R.id.second_other_box);

        second_other_box.setVisibility(View.GONE);

        quickening.setVisibility(View.GONE);
        bleeding_piv.setVisibility(View.GONE);
        leak_piv.setVisibility(View.GONE);
        pih.setVisibility(View.GONE);
        tt.setVisibility(View.GONE);
        iron.setVisibility(View.GONE);
        second_other.setVisibility(View.GONE);

    }


}
