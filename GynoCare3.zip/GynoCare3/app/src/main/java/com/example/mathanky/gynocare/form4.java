package com.example.mathanky.gynocare;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class form4 extends AppCompatActivity {

    private static Button btnNext6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.form4);
        btnNext6=(Button)findViewById(R.id.next_page6);
        onBtnNext6();
    }

    public void onBtnNext6()
    {
        btnNext6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent("com.example.mathanky.gynocare.form5");
                startActivity(intent);
            }
        });
    }

}
