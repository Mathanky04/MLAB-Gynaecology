package com.example.mathanky.gynocare;


/**
 * Created by Shruthi on 7/25/2016.
 */

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class form16 extends AppCompatActivity {

    private static TextView btnNext2;
    EditText e1,e2,e3,e4,e5,e6, e7, e8, e9;
    RadioGroup rg1, rg2, rg3, rg4, rg5,rg6,rg7,rg8, rg9;
    RadioButton selectedRadioButton, sr2, sr3, sr4, sr5, sr6, sr7, sr8, sr9;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.form16);

        e1 = (EditText)findViewById(R.id.CVS_box) ;
        e2 = (EditText)findViewById(R.id.RS_box) ;
        e3 = (EditText)findViewById(R.id.CNS_box) ;

        e1.setVisibility(View.GONE);
        e2.setVisibility(View.GONE);
        e3.setVisibility(View.GONE);

        btnNext2=(TextView)findViewById(R.id.next_page16);
        onButton();
    }

    public void onButton()
    {
        btnNext2=(TextView) findViewById(R.id.next_page16);
        btnNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ValidationSuccess()){
                    onBtnNext2();
                }
            }
        });
    }

    private boolean ValidationSuccess(){

        boolean check=true;
        StringBuilder errMsg = new StringBuilder("");


        rg2 = (RadioGroup)findViewById(R.id.RS);
        sr2 = (RadioButton)findViewById(R.id.RS_abnormal);
        rg3 = (RadioGroup)findViewById(R.id.CNS);
        sr3 = (RadioButton)findViewById(R.id.CNS_abnormal);

        rg1=(RadioGroup)findViewById(R.id.CVS);
        selectedRadioButton = (RadioButton)findViewById(R.id.CVS_abnormal);

        if (rg1.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg2.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if (rg3.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if(selectedRadioButton.isChecked())
        {
            e1 = (EditText)findViewById(R.id.CVS_box) ;
            if (e1.getText().toString().equalsIgnoreCase("")){
                e1.setError("Please enter a value");
                check=false;
            }
        }

        if(sr2.isChecked())
        {
            e2 = (EditText)findViewById(R.id.RS_box) ;
            if (e2.getText().toString().equalsIgnoreCase("")){
                e2.setError("Please enter a value");
                check=false;
            }
        }

        if(sr3.isChecked())
        {
            e3 = (EditText)findViewById(R.id.CNS_box) ;
            if (e3.getText().toString().equalsIgnoreCase("")){
                e3.setError("Please enter a value");
                check=false;
            }
        }

        e1 = (EditText)findViewById(R.id.inspection) ;
        if (e1.getText().toString().equalsIgnoreCase("")){
            e1.setError("Please enter a value");
            check=false;
        }

        e1 = (EditText)findViewById(R.id.palpitation) ;
        if (e1.getText().toString().equalsIgnoreCase("")){
            e1.setError("Please enter a value");
            check=false;
        }

        e1 = (EditText)findViewById(R.id.ascultation) ;
        if (e1.getText().toString().equalsIgnoreCase("")){
            e1.setError("Please enter a value");
            check=false;
        }

        e1 = (EditText)findViewById(R.id.percussion) ;
        if (e1.getText().toString().equalsIgnoreCase("")){
            e1.setError("Please enter a value");
            check=false;
        }

        e1 = (EditText)findViewById(R.id.speculum_examination) ;
        if (e1.getText().toString().equalsIgnoreCase("")){
            e1.setError("Please enter a value");
            check=false;
        }

        e1 = (EditText)findViewById(R.id.local_examination) ;
        if (e1.getText().toString().equalsIgnoreCase("")){
            e1.setError("Please enter a value");
            check=false;
        }

        e1 = (EditText)findViewById(R.id.bimanual_examination) ;
        if (e1.getText().toString().equalsIgnoreCase("")){
            e1.setError("Please enter a value");
            check=false;
        }

        e1 = (EditText)findViewById(R.id.rectal_examination) ;
        if (e1.getText().toString().equalsIgnoreCase("")){
            e1.setError("Please enter a value");
            check=false;
        }

        e1 = (EditText)findViewById(R.id.provisional_diagnosis) ;
        if (e1.getText().toString().equalsIgnoreCase("")){
            e1.setError("Please enter a value");
            check=false;
        }


        return check;
    }

    public void onBtnNext2()
    {

        btnNext2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent("com.example.mathanky.gynocare.form17");
                startActivity(intent);
            }
        });
    }

    public void click(View view)
    {
        e1 = (EditText)findViewById(R.id.menstrual_history_box) ;
        e1.setVisibility(View.VISIBLE);
    }

    public void click1(View view)
    {
        e1 = (EditText)findViewById(R.id.menstrual_history_box) ;
        e1.setVisibility(View.GONE);
    }

    public void click2(View view)
    {
        e2 = (EditText)findViewById(R.id.contraceptive_history_box) ;
        e2.setVisibility(View.VISIBLE);
    }

    public void click3(View view)
    {
        e2 = (EditText)findViewById(R.id.contraceptive_history_box) ;
        e2.setVisibility(View.GONE);
    }

    public void click4(View view)
    {
        e3 = (EditText)findViewById(R.id.past_history_box) ;
        e3.setVisibility(View.VISIBLE);
    }

    public void click5(View view)
    {
        e3 = (EditText)findViewById(R.id.past_history_box) ;
        e3.setVisibility(View.GONE);
    }

    public void click6(View view)
    {
        e4 = (EditText)findViewById(R.id.family_history_box) ;
        e4.setVisibility(View.VISIBLE);
    }

    public void click7(View view)
    {
        e4 = (EditText)findViewById(R.id.family_history_box) ;
        e4.setVisibility(View.GONE);
    }

    public void click8(View view)
    {
        e5 = (EditText)findViewById(R.id.addictive_habits_box) ;
        e5.setVisibility(View.VISIBLE);
    }

    public void click9(View view)
    {
        e5 = (EditText)findViewById(R.id.addictive_habits_box) ;
        e5.setVisibility(View.GONE);
    }

    public void click10(View view)
    {
        e6 = (EditText)findViewById(R.id.allergies_known_box) ;
        e6.setVisibility(View.VISIBLE);
    }

    public void click11(View view)
    {
        e6 = (EditText)findViewById(R.id.allergies_known_box) ;
        e6.setVisibility(View.GONE);
    }


}
