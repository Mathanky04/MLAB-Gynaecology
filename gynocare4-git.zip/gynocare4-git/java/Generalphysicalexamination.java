package com.example.mathanky.gynocare4;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import static com.example.mathanky.gynocare4.generalinfo.id;
public class Generalphysicalexamination extends AppCompatActivity {

    private EditText e1,e2,e3,e4,e5,e6, e7, e8, e9,h,w,bmi,pr,bp;
    RadioGroup rg1,rg2,rg3,rg4,rg5,rg6,rg7,rg8,rg9,rg10,rg11,rg12;
    RadioButton selectedRadioButton, sr2, sr3, sr4, sr5, sr6, sr7, sr8, sr9, sr10,sr12,t1,t2,p1,p2,p3;
    SQLiteDatabase database;
    //String id="1234";
    String table_query = "patient_id TEXT ," +
            " height TEXT ," +
            " weight TEXT ," +
            " bmi_pre_pregnancy TEXT ," +
            " pr TEXT ," +
            " bp TEXT , " +
            "temp TEXT ," +
            " breasts TEXT ," +
            "nipples TEXT ," +
            "thyroid TEXT ," +
            "spine TEXT ,i" +
            "cterus TEXT ," +
            "pallor TEXT ," +
            "edema TEXT , " +
            "cyanosis TEXT ," +
            "clubbing TEXT ," +
            "lymphadenopathy TEXT ," +
            "update_status TEXT DEFAULT \"No\"," +
            "timestamp TEXT , " +
            "primary key(patient_id), " +
            "foreign key(patient_id) references general_information(patient_id)";
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generalphysicalexamination);
        h = (EditText) findViewById(R.id.height);
        w = (EditText) findViewById(R.id.weight);
        bmi = (EditText) findViewById(R.id.bmi);
        pr = (EditText) findViewById(R.id.pr);
        bp = (EditText) findViewById(R.id.bp);
        e1 = (EditText) findViewById(R.id.breasts_box);
        e2 = (EditText) findViewById(R.id.nipples_box);
        e3 = (EditText) findViewById(R.id.thyroid_box);
        e4 = (EditText) findViewById(R.id.spine_box);
        e5 = (EditText) findViewById(R.id.icterus_box);
        rg11 = (RadioGroup)findViewById(R.id.pallor_positive);
        e6 = (EditText) findViewById(R.id.edema_box);
        e7 = (EditText) findViewById(R.id.cyanosis_box);
        e8 = (EditText) findViewById(R.id.clubbing_box);
        e9 = (EditText) findViewById(R.id.lymphadenopathy_box);
        p1 =(RadioButton)findViewById(R.id.pallor_single) ;
        p2 =(RadioButton)findViewById(R.id.pallor_double) ;
        p3 =(RadioButton)findViewById(R.id.pallor_triple) ;
        rg1 = (RadioGroup) findViewById(R.id.breasts);
        selectedRadioButton = (RadioButton) findViewById(R.id.breasts_abnormal);
        rg2 = (RadioGroup) findViewById(R.id.nipples);
        sr2 = (RadioButton) findViewById(R.id.nipples_retracted);
        rg3 = (RadioGroup) findViewById(R.id.thyroid);
        sr3 = (RadioButton) findViewById(R.id.thyroid_abnormal);
        rg4 = (RadioGroup) findViewById(R.id.spine);
        sr4 = (RadioButton) findViewById(R.id.spine_abnormal);
        rg5 = (RadioGroup) findViewById(R.id.icterus);
        sr5 = (RadioButton) findViewById(R.id.icterus_present);
        rg6 = (RadioGroup) findViewById(R.id.pallor);
        sr6 = (RadioButton) findViewById(R.id.pallor_present);
        rg7 = (RadioGroup) findViewById(R.id.edema);
        sr7 = (RadioButton) findViewById(R.id.edema_present);
        rg8 = (RadioGroup) findViewById(R.id.cyanosis);
        sr8 = (RadioButton) findViewById(R.id.cyanosis_present);
        rg9 = (RadioGroup) findViewById(R.id.clubbing);
        sr9 = (RadioButton) findViewById(R.id.clubbing_present);
        rg10 = (RadioGroup) findViewById(R.id.lymphadenopathy);
        sr10 = (RadioButton) findViewById(R.id.lymphadenopathy_present);
        rg12 = (RadioGroup) findViewById(R.id.temp);
        sr12 = (RadioButton)findViewById(R.id.febrile);
        e1.setVisibility(View.GONE);
        e2.setVisibility(View.GONE);
        e3.setVisibility(View.GONE);
        e4.setVisibility(View.GONE);
        e5.setVisibility(View.GONE);
        e6.setVisibility(View.GONE);
        e7.setVisibility(View.GONE);
        e8.setVisibility(View.GONE);
        e9.setVisibility(View.GONE);
        p1.setVisibility(View.GONE);
        p2.setVisibility(View.GONE);
        p3.setVisibility(View.GONE);
        //rg11.setVisibility(View.GONE);
        //opening db
        database = openOrCreateDatabase("gynaecology", Context.MODE_PRIVATE, null);

        //creating table if doesn't exist
        database.execSQL("CREATE TABLE IF NOT EXISTS general_physical_examination (" + table_query + ")");
    }

    @Override
    public void onBackPressed() { }

    public void onProceed(View view) {
        if (ValidationSuccess()) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
            String format = simpleDateFormat.format(new Date());
            String t="Afebrile",b="Normal",np="Normal",th="Normal",sp="Normal",ic="NOT SPECIFIED",pl="Absent",ed="Absent",cy="Absent",clb="Absent",lym="Absent";
            if(sr12.isChecked())
                t="Febrile";
            if(selectedRadioButton.isChecked())
                b=e1.getText().toString().trim();
            if(sr2.isChecked())
                np=e2.getText().toString().trim();
            if(sr3.isChecked())
                th=e3.getText().toString().trim();
            if(sr4.isChecked())
                sp=e4.getText().toString().trim();
            if(sr5.isChecked())
                ic=e5.getText().toString().trim();
            if(sr6.isChecked())
            {
                if(p1.isChecked())
                    pl="+";
                else if(p2.isChecked())
                    pl="++";
                else if(p3.isChecked())
                    pl="+++";
            }
            if(sr7.isChecked())
                ed=e6.getText().toString().trim();
            if(sr8.isChecked())
                cy=e7.getText().toString().trim();
            if(sr9.isChecked())
                clb=e8.getText().toString().trim();
            if(sr10.isChecked())
                lym=e9.getText().toString().trim();



            String insert_query ="'" + id.toString().trim() + "'," +
                    "'" + h.getText().toString().trim() + "'," +
                    "'" + w.getText().toString().trim() + "'," +
                    "'" + bmi.getText().toString().trim() + "'," +
                    "'" + pr.getText().toString().trim() + "'," +
                    "'" + bp.getText().toString().trim() + "'," +
                    "'" + t + "'," +
                    "'" + b + "'," +
                    "'" + np + "'," +
                    "'" + th + "'," +
                    "'" + sp + "'," +
                    "'" + ic + "'," +
                    "'" + pl + "'," +
                    "'" + ed + "'," +
                    "'" + cy + "'," +
                    "'" + clb + "'," +
                    "'" + lym + "'," +
                    "'" + "No" + "'," +
                    "'" + format.toString().trim() + "'";
            System.out.println("InsertQuery:" + insert_query);
            //inserting into database
            database.execSQL("INSERT INTO general_physical_examination VALUES (" + insert_query + ")");

            Toast.makeText(getApplicationContext(), "Successful", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(getApplicationContext(), obs_systemic_examination.class);
            startActivity(intent);

        } else {
            Toast.makeText(getApplicationContext(), "Please check the details", Toast.LENGTH_LONG).show();
        }
        database.close();


    }

    private boolean ValidationSuccess() {

        boolean check = true;
        StringBuilder errMsg = new StringBuilder("");
        e1 = (EditText) findViewById(R.id.height);
        if (e1.getText().toString().equalsIgnoreCase("")) {
            e1.setError("Please enter a value");
            check = false;
        }

        e1 = (EditText) findViewById(R.id.weight);
        if (e1.getText().toString().equalsIgnoreCase("")) {
            e1.setError("Please enter a value");
            check = false;
        }

        e1 = (EditText) findViewById(R.id.pr);
        if (e1.getText().toString().equalsIgnoreCase("")) {
            e1.setError("Please enter a value");
            check = false;
        }

        e1 = (EditText) findViewById(R.id.bp);
        if (e1.getText().toString().equalsIgnoreCase("")) {
            e1.setError("Please enter a value");
            check = false;
        }

        if (rg1.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg12.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg2.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg3.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg4.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg5.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg6.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg7.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg8.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg9.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg10.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (selectedRadioButton.isChecked()) {
            e1 = (EditText) findViewById(R.id.breasts_box);
            if (e1.getText().toString().equalsIgnoreCase("")) {
                e1.setError("Please enter a value");
                check = false;
            }
        }

        if (sr2.isChecked()) {
            e2 = (EditText) findViewById(R.id.nipples_box);
            if (e2.getText().toString().equalsIgnoreCase("")) {
                e2.setError("Please enter a value");
                check = false;
            }
        }

        if (sr3.isChecked()) {
            e3 = (EditText) findViewById(R.id.thyroid_box);
            if (e3.getText().toString().equalsIgnoreCase("")) {
                e3.setError("Please enter a value");
                check = false;
            }
        }

        if (sr4.isChecked()) {
            e4 = (EditText) findViewById(R.id.spine_box);
            if (e4.getText().toString().equalsIgnoreCase("")) {
                e4.setError("Please enter a value");
                check = false;
            }
        }

        if (sr5.isChecked()) {
            e5 = (EditText) findViewById(R.id.icterus_box);
            if (e5.getText().toString().equalsIgnoreCase("")) {
                e5.setError("Please enter a value");
                check = false;
            }
        }

        if (sr6.isChecked()) {
            rg11 = (RadioGroup) findViewById(R.id.pallor_positive);
            if (rg11.getCheckedRadioButtonId() == -1) {
                errMsg.append("Please select on option\n");
                check = false;
            }
        }

        if (sr7.isChecked()) {
            e5 = (EditText) findViewById(R.id.edema_box);
            if (e5.getText().toString().equalsIgnoreCase("")) {
                e5.setError("Please enter a value");
                check = false;
            }
        }

        if (sr8.isChecked()) {
            e5 = (EditText) findViewById(R.id.cyanosis_box);
            if (e5.getText().toString().equalsIgnoreCase("")) {
                e5.setError("Please enter a value");
                check = false;
            }
        }

        if (sr9.isChecked()) {
            e5 = (EditText) findViewById(R.id.clubbing_box);
            if (e5.getText().toString().equalsIgnoreCase("")) {
                e5.setError("Please enter a value");
                check = false;
            }
        }

        if (sr10.isChecked()) {
            e5 = (EditText) findViewById(R.id.lymphadenopathy_box);
            if (e5.getText().toString().equalsIgnoreCase("")) {
                e5.setError("Please enter a value");
                check = false;
            }
        }


        return check;
    }

    public void click(View view)
    {
        e1.setVisibility(View.VISIBLE);
    }
    public void click1(View view)
    {
        e1.setVisibility(View.GONE);
    }

    public void click2(View view)
    {
        e2.setVisibility(View.VISIBLE);
    }
    public void click3(View view)
    {
        e2.setVisibility(View.GONE);
    }

    public void click4(View view)
    {
        e3.setVisibility(View.VISIBLE);
    }
    public void click5(View view)
    {
        e3.setVisibility(View.GONE);
    }

    public void click6(View view)
    {
        e4.setVisibility(View.VISIBLE);
    }
    public void click7(View view)
    {
        e4.setVisibility(View.GONE);
    }

    public void click8(View view)
    {
        e5.setVisibility(View.VISIBLE);
    }
    public void click9(View view)
    {
        e5.setVisibility(View.GONE);
    }

    public void click10(View view)
    {
        p1.setVisibility(View.VISIBLE);
        p2.setVisibility(View.VISIBLE);
        p3.setVisibility(View.VISIBLE);
    }
    public void click11(View view)
    {
        p1.setVisibility(View.GONE);
        p2.setVisibility(View.GONE);
        p3.setVisibility(View.GONE);
    }

    public void click12(View view)
    {
        e6.setVisibility(View.VISIBLE);
    }
    public void click13(View view)
    {
        e6.setVisibility(View.GONE);
    }

    public void click14(View view)
    {
        e7.setVisibility(View.VISIBLE);
    }
    public void click15(View view)
    {
        e7.setVisibility(View.GONE);
    }

    public void click16(View view)
    {
        e8.setVisibility(View.VISIBLE);
    }
    public void click17(View view)
    {
        e8.setVisibility(View.GONE);
    }

    public void click18(View view)
    {
        e9.setVisibility(View.VISIBLE);
    }
    public void click19(View view)
    {
        e9.setVisibility(View.GONE);
    }
}
