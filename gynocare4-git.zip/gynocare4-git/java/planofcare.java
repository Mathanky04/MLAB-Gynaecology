package com.example.mathanky.gynocare4;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

import static com.example.mathanky.gynocare4.generalinfo.id;

public class planofcare extends AppCompatActivity {
    private EditText e1, e2;
    SQLiteDatabase database;

    String table_query = "patient_id TEXT ," +
            "gynaec_plan_of_care TEXT ," +
            "gynaec_advice TEXT ," +
            "update_status TEXT DEFAULT \"No\"," +
            "timestamp TEXT ," +
            "primary key(patient_id)," +
            "foreign key(patient_id) references general_information(patient_id)";

    @Override
    public void onBackPressed() { }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_planofcare);
        e1 = (EditText) findViewById(R.id.g_plan);
        e2 = (EditText) findViewById(R.id.g_advice);
        //opening db
        database = openOrCreateDatabase("gynaecology", Context.MODE_PRIVATE, null);

        //creating table if doesn't exist
        database.execSQL("CREATE TABLE IF NOT EXISTS planof_care(" + table_query + ")");
    }
    public void onProceed(View view) {
        if (ValidationSuccess()) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
            String format = simpleDateFormat.format(new Date());
            String insert_query ="'" + id.toString().trim() + "'," +
                    "'"+e1.getText().toString().trim()+"',"+
                    "'"+e2.getText().toString().trim()+"',"+
                    "'"+"No"+"',"+
                    "'"+format.toString().trim()+"'";
            System.out.println("InsertQuery:"+insert_query);
            //inserting into database
            database.execSQL("INSERT INTO planof_care VALUES (" + insert_query + ")");
            Toast.makeText(getApplicationContext(), "Successful", Toast.LENGTH_LONG).show();
            Intent intent  = new Intent(getApplicationContext(),planofcare.class);
            startActivity(intent);

        } else {
            Toast.makeText(getApplicationContext(), "Please check the details", Toast.LENGTH_LONG).show();
        }
    }
    private boolean ValidationSuccess(){

        boolean check=true;
        StringBuilder errMsg = new StringBuilder("");

        e1 = (EditText)findViewById(R.id.g_plan) ;
        if (e1.getText().toString().equalsIgnoreCase("")){
            e1.setError("Please enter a value");
            check=false;
        }
        e2 = (EditText)findViewById(R.id.g_advice) ;
        if (e2.getText().toString().equalsIgnoreCase("")){
            e2.setError("Please enter a value");
            check=false;
        }

        return check;
    }

}
