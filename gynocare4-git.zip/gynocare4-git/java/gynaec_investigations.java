package com.example.mathanky.gynocare4;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import static com.example.mathanky.gynocare4.generalinfo.id;
public class gynaec_investigations extends AppCompatActivity {
    //String id="123";
    Button btnNext2;
    EditText e1, e2, e3, e4;
    RadioGroup rg1, rg2, rg3, rg4, rg5, rg6, rg7, rg8, rg9, rg10, rg11, rg12, rg13;
    RadioButton selectedRadioButton, tc, pc, ps, b1, b2, b3, b4, b5, b6, b7, b8, a, s, m, cs, hiv, fbs, ppbs, u, pap;
    SQLiteDatabase database;
    String table_query = "patient_id TEXT ," +
            "gynaec_hb TEXT ," +
            "gynaec_tc TEXT ," +
            "gynaec_platelet_count TEXT ," +
            "gynaec_peripheral_smear TEXT ," +
            "gynaec_blood_grouping_rh_typing TEXT ," +
            "gynaec_albumin TEXT ," +
            "gynaec_sugar TEXT ," +
            "gynaec_microscopy TEXT ," +
            "gynaec_cs TEXT ," +
            "gynaec_hiv TEXT ," +
            "gynaec_hbsag TEXT ," +
            "gynaec_vdrl TEXT ," +
            "gynaec_rbs TEXT ," +
            "gynaec_fbs TEXT ," +
            "gynaec_ppbs TEXT ," +
            "gynaec_ultrasound TEXT ," +
            "gynaec_pap_smear TEXT ," +
            "update_status TEXT DEFAULT \"No\"," +
            "timestamp TEXT ," +
            "primary key(patient_id)," +
            "foreign key(patient_id) references general_information(patient_id)";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gynaec_investigations);
        e1 = (EditText) findViewById(R.id.g_Hb_inv_box);
        e2 = (EditText) findViewById(R.id.g_HbsAg);
        e3 = (EditText) findViewById(R.id.g_VDRL);
        e4 = (EditText) findViewById(R.id.g_RBS);
        rg1 = (RadioGroup) findViewById(R.id.g_TC);
        rg2 = (RadioGroup) findViewById(R.id.g_platelet_count);
        rg3 = (RadioGroup) findViewById(R.id.g_Peripheral_Smear);
        rg4 = (RadioGroup) findViewById(R.id.g_blood_grouping);
        rg5 = (RadioGroup) findViewById(R.id.g_albumin);
        rg6 = (RadioGroup) findViewById(R.id.g_Sugar);
        rg7 = (RadioGroup) findViewById(R.id.g_Microscopy);
        rg8 = (RadioGroup) findViewById(R.id.g_CS);
        rg9 = (RadioGroup) findViewById(R.id.g_HIV);
        rg10 = (RadioGroup) findViewById(R.id.g_FBS);
        rg11 = (RadioGroup) findViewById(R.id.g_PPBS);
        rg12 = (RadioGroup) findViewById(R.id.g_Ultrasound);
        rg13 = (RadioGroup) findViewById(R.id.g_Pap_Smear);
        tc = (RadioButton) findViewById(R.id.g_TC_normal);
        pc = (RadioButton) findViewById(R.id.g_platelet_count_normal);
        ps = (RadioButton) findViewById(R.id.g_Peripheral_Smear_normal);
        b1 = (RadioButton) findViewById(R.id.g_Aplus);
        b2 = (RadioButton) findViewById(R.id.g_Aminus);
        b3 = (RadioButton) findViewById(R.id.g_Bplus);
        b4 = (RadioButton) findViewById(R.id.g_Bminus);
        b5 = (RadioButton) findViewById(R.id.g_Oplus);
        b6 = (RadioButton) findViewById(R.id.g_Ominus);
        b7 = (RadioButton) findViewById(R.id.g_ABplus);
        b8 = (RadioButton) findViewById(R.id.g_ABminus);
        a = (RadioButton) findViewById(R.id.g_albumin_normal);
        s = (RadioButton) findViewById(R.id.g_Sugar_normal);
        m = (RadioButton) findViewById(R.id.g_Microscopy_normal);
        cs = (RadioButton) findViewById(R.id.g_CS_normal);
        hiv = (RadioButton) findViewById(R.id.g_HIV_positive);
        fbs = (RadioButton) findViewById(R.id.g_FBS_positive);
        ppbs = (RadioButton) findViewById(R.id.g_PPBS_positive);
        u = (RadioButton) findViewById(R.id.g_Ultrasound_positive);
        pap = (RadioButton) findViewById(R.id.g_Pap_Smear_positive);
        //opening db
        database = openOrCreateDatabase("gynaecology", Context.MODE_PRIVATE, null);

        //creating table if doesn't exist
        database.execSQL("CREATE TABLE IF NOT EXISTS gyno_investigations (" + table_query + ")");
    }

    @Override
    public void onBackPressed() { }

    public void onProceed(View view) {
        if (ValidationSuccess()) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
            String format = simpleDateFormat.format(new Date());
            String tc1 ="Abnormal",pc1="Abnormal",psr = "Abnormal",bg="Not Specified" ,alb ="Abnormal",sg="Abnormal",mic="Abnormal",cs1="Abnormal",hv="Negative",fs="Abnormal",ppb="Abnormal",ult="Abnormal",pps="Abnormal";
            if(tc.isChecked())
                tc1="Normal";
            if(pc.isChecked())
                pc1="Normal";
            if(ps.isChecked())
                psr="Normal";
            if(b1.isChecked())
                bg="A+";
            if(b2.isChecked())
                bg="A-";
            if(b3.isChecked())
                bg="B+";
            if(b4.isChecked())
                bg="B-";
            if(b5.isChecked())
                bg="O+";
            if(b6.isChecked())
                bg="O-";
            if(b7.isChecked())
                bg="AB+";
            if(b8.isChecked())
                bg="AB-";
            if(a.isChecked())
                alb="Normal";
            if(s.isChecked())
                sg="Normal";
            if(m.isChecked())
                mic="Normal";
            if(cs.isChecked())
                cs1="Normal";
            if(hiv.isChecked())
                hv="Positive";
            if(fbs.isChecked())
                fs="Normal";
            if(ppbs.isChecked())
                ppb="Normal";
            if(u.isChecked())
                ult="Normal";
            if(ppbs.isChecked())
                pps="Normal";
            String insert_query = "'" + id.toString().trim() + "'," +
                    "'" + e1.getText().toString().trim() + "'," +
                    "'" + tc1 + "'," +
                    "'" + pc1 + "'," +
                    "'" + psr + "'," +
                    "'" + bg + "'," +
                    "'" + alb + "'," +
                    "'" + sg + "'," +
                    "'" + mic + "'," +
                    "'" + cs1 + "'," +
                    "'" + hv + "'," +
                    "'" + e2.getText().toString().trim() + "'," +
                    "'" + e3.getText().toString().trim() + "'," +
                    "'" + e4.getText().toString().trim() + "'," +
                    "'" + fs + "'," +
                    "'" + ppb + "'," +
                    "'" + ult + "'," +
                    "'" + pps + "'," +
                    "'" + "No" + "'," +
                    "'" + format.toString().trim() + "'";
            System.out.println("InsertQuery:" + insert_query);
            //inserting into database
            database.execSQL("INSERT INTO gyno_investigations VALUES (" + insert_query + ")");
            Toast.makeText(getApplicationContext(), "Successful", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(getApplicationContext(), thankyou.class);
            startActivity(intent);

        } else {
            Toast.makeText(getApplicationContext(), "Please check the details", Toast.LENGTH_LONG).show();
        }



    }

    private boolean ValidationSuccess() {

        boolean check = true;
        StringBuilder errMsg = new StringBuilder("");
        if (e1.getText().toString().equalsIgnoreCase("")) {
            e1.setError("Please enter a value");
            check = false;
        }

        if (Integer.parseInt(e1.getText().toString()) > 100) {
            e1.setError("Exceeds limit! Please enter a valid percentage");
            return false;
        }

        if (e2.getText().toString().equalsIgnoreCase("")) {
            e2.setError("Please enter a value");
            check = false;
        }

        if (e3.getText().toString().equalsIgnoreCase("")) {
            e3.setError("Please enter a value");
            check = false;
        }

        if (e4.getText().toString().equalsIgnoreCase("")) {
            e4.setError("Please enter a value");
            check = false;
        }

        if (rg1.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg2.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg3.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg4.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg5.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg6.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }
        if (rg7.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg8.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg9.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }
        if (rg10.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg11.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }

        if (rg12.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }
        if (rg13.getCheckedRadioButtonId() == -1) {
            errMsg.append("Please select on option\n");
            check = false;
        }
        return check;
    }



}