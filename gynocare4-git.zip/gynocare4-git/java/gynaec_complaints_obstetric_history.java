package com.example.mathanky.gynocare4;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

import static com.example.mathanky.gynocare4.generalinfo.id;
public class gynaec_complaints_obstetric_history extends AppCompatActivity {

    SQLiteDatabase database;
    String table_gynaec_complaints="patient_id TEXT ,gynaec_chief_complaints TEXT , gynaec_lmp TEXT ,gynaec_history_of_present_illness TEXT , gynaec_menstrual_history TEXT ,update_status TEXT DEFAULT \"No\", timestamp TEXT ,primary key(patient_id), foreign key(patient_id) references general_information(patient_id)";
    String table_gynaec_obstetric_history="patient_id TEXT ,gynaec_married_life TEXT , gynaec_p TEXT , gynnaec_a TEXT , gynaec_l TEXT ,update_status TEXT DEFAULT \"No\", timestamp TEXT , primary key(patient_id), foreign key(patient_id) references general_information(patient_id)";
    EditText chief_complaints,hist_illness,mens_reg,mens_irreg,married_life,p,a,l,l1,l2,l3;
    RadioButton m1,m2; String m;
    RadioGroup rg1;
    Button btnNext;

    @Override
    public void onBackPressed() { }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gynaec_complaints_obstetric_history);
        database = openOrCreateDatabase("gynaecology", Context.MODE_PRIVATE, null);
        database.execSQL("CREATE TABLE IF NOT EXISTS gynaec_complaints(" + table_gynaec_complaints + ")");
        database.execSQL("CREATE TABLE IF NOT EXISTS gynaec_obstetric_history(" + table_gynaec_obstetric_history + ")");
        chief_complaints=(EditText)findViewById(R.id.g_chief_complaints);
        l1=(EditText)findViewById(R.id.g_lmp_day_box);
        l2=(EditText)findViewById(R.id.g_lmp_month_box);
        l3=(EditText)findViewById(R.id.g_lmp_year_box);
        hist_illness=(EditText)findViewById(R.id.g_hist_of_pres_illness_box);
        mens_reg=(EditText)findViewById(R.id.g_menstrual_history_regular_box);
        mens_irreg=(EditText)findViewById(R.id.g_menstrual_history_irregular_box);
        married_life=(EditText)findViewById(R.id.g_married_life);
        p=(EditText)findViewById(R.id.g_P_box);
        a=(EditText)findViewById(R.id.g_A_box);
        l=(EditText)findViewById(R.id.g_L_box);
        m1=(RadioButton)findViewById(R.id.g_menstrual_history_regular);
        m2=(RadioButton)findViewById(R.id.g_menstrual_history_irregular);
        rg1=(RadioGroup)findViewById(R.id.g_menstrual_history);
        mens_reg.setVisibility(View.GONE);
        mens_irreg.setVisibility(View.GONE);
        btnNext=(Button)findViewById(R.id.next_page10);
        onButton();
    }

    public void onButton()
    {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy-hh-mm-ss");
        final String format = simpleDateFormat.format(new Date());
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ValidationSuccess())
                {
                    String m ="";
                    String lmp="";
                    lmp=l1.getText().toString().trim()+"/"+l2.getText().toString().trim()+"/"+l3.getText().toString().trim();
                    if(m1.isChecked())
                        m ="Regular-"+mens_reg.getText().toString();
                    else if(m2.isChecked())
                        m ="Irregular-"+mens_irreg.getText().toString();
                    String insert_gynaec_complaints="'"+id.toString().trim()+"','"+chief_complaints.getText().toString().trim()+"','"+lmp+"','"+hist_illness.getText().toString().trim()+"','"+m+"','"+"No"+"','"+format.toString().trim()+"'";
                    String insert_gynaec_obstetric_history="'"+id.toString().trim()+"','"+married_life.getText().toString().trim()+"','"+p.getText().toString().trim()+"','"+a.getText().toString()+"','"+l.getText().toString()+"','"+"No"+"','"+format.toString().trim()+"'";
                    System.out.println("InsertQuery:" + insert_gynaec_complaints);
                    System.out.println("InsertQuery:" + insert_gynaec_obstetric_history);
                    //inserting into database
                    database.execSQL("INSERT INTO gynaec_complaints VALUES (" + insert_gynaec_complaints + ")");
                    database.execSQL("INSERT INTO gynaec_obstetric_history VALUES (" + insert_gynaec_obstetric_history+" )");
                    Toast.makeText(getApplicationContext(), "Successful", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), pasthistory.class);
                    startActivity(intent);

                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Please check the details", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private boolean ValidationSuccess(){

        boolean check=true;
        StringBuilder errMsg = new StringBuilder("");
        if (chief_complaints.getText().toString().equalsIgnoreCase("")){
            chief_complaints.setError("Please enter a value");
            check=false;
        }

        if (l1.getText().toString().equalsIgnoreCase("")){
            l1.setError("Please enter a value");
            check=false;
        }

        if (l2.getText().toString().equalsIgnoreCase("")){
            l2.setError("Please enter a value");
            check=false;
        }

        if (l3.getText().toString().equalsIgnoreCase("")){
            l3.setError("Please enter a value");
            check=false;
        }

        if (hist_illness.getText().toString().equalsIgnoreCase("")){
            hist_illness.setError("Please enter a value");
            check=false;
        }

        if (married_life.getText().toString().equalsIgnoreCase("")){
            married_life.setError("Please enter a value");
            check=false;
        }

        if (p.getText().toString().equalsIgnoreCase("")){
            p.setError("Please enter a value");
            check=false;
        }

        if (a.getText().toString().equalsIgnoreCase("")){
            a.setError("Please enter a value");
            check=false;
        }

        if (l.getText().toString().equalsIgnoreCase("")){
            l.setError("Please enter a value");
            check=false;
        }


        if (rg1.getCheckedRadioButtonId() == -1)
        {
            errMsg.append("Please select on option\n");
            check=false;
        }

        if(m1.isChecked())
        {
            if (mens_reg.getText().toString().equalsIgnoreCase("")){
                mens_reg.setError("Please enter a value");
                check=false;
            }
        }

        if(m2.isChecked())
        {
            if (mens_irreg.getText().toString().equalsIgnoreCase("")){
                mens_irreg.setError("Please enter a value");
                check=false;
            }
        }

        return check;
    }

    public void click(View view)
    {
        mens_reg.setVisibility(View.VISIBLE);
        mens_irreg.setVisibility(View.GONE);
    }

    public void click1(View view)
    {
        mens_reg.setVisibility(View.GONE);
        mens_irreg.setVisibility(View.VISIBLE);
    }
}
